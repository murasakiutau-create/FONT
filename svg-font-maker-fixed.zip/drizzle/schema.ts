import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// TODO: Add your tables here

export const fontProjects = mysqlTable("font_projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  author: varchar("author", { length: 255 }),
  description: text("description"),
  upm: int("upm").default(1000).notNull(),
  ascender: int("ascender").default(800).notNull(),
  descender: int("descender").default(-200).notNull(),
  // Default side bearings applied to all glyphs unless overridden per-glyph
  defaultLsb: int("defaultLsb").default(50).notNull(),
  defaultRsb: int("defaultRsb").default(50).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FontProject = typeof fontProjects.$inferSelect;
export type InsertFontProject = typeof fontProjects.$inferInsert;

export const glyphs = mysqlTable("glyphs", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  unicode: int("unicode").notNull(),
  char: varchar("char", { length: 8 }).notNull(),
  svgUrl: text("svgUrl").notNull(),
  svgKey: varchar("svgKey", { length: 512 }).notNull(),
  width: int("width").default(600).notNull(),
  pathData: text("pathData"),
  // Per-glyph side bearings (null = use project default)
  lsb: int("lsb"),
  rsb: int("rsb"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Glyph = typeof glyphs.$inferSelect;
export type InsertGlyph = typeof glyphs.$inferInsert;

export const fontFiles = mysqlTable("font_files", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  format: mysqlEnum("format", ["ttf", "otf"]).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FontFile = typeof fontFiles.$inferSelect;
export type InsertFontFile = typeof fontFiles.$inferInsert;