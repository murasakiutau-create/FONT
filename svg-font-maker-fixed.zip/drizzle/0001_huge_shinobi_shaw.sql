CREATE TABLE `font_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`format` enum('ttf','otf') NOT NULL,
	`fileUrl` text NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `font_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `font_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`author` varchar(255),
	`description` text,
	`upm` int NOT NULL DEFAULT 1000,
	`ascender` int NOT NULL DEFAULT 800,
	`descender` int NOT NULL DEFAULT -200,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `font_projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `glyphs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`unicode` int NOT NULL,
	`char` varchar(8) NOT NULL,
	`svgUrl` text NOT NULL,
	`svgKey` varchar(512) NOT NULL,
	`width` int NOT NULL DEFAULT 600,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `glyphs_id` PRIMARY KEY(`id`)
);
