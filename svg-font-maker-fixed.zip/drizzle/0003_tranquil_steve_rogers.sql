ALTER TABLE `font_projects` ADD `defaultLsb` int DEFAULT 50 NOT NULL;--> statement-breakpoint
ALTER TABLE `font_projects` ADD `defaultRsb` int DEFAULT 50 NOT NULL;--> statement-breakpoint
ALTER TABLE `glyphs` ADD `lsb` int;--> statement-breakpoint
ALTER TABLE `glyphs` ADD `rsb` int;