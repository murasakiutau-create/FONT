import { useRef, useEffect, useCallback, useState, useMemo } from "react";

// ---- SVG transform matrix helpers ----
// Represents a 2D affine matrix as [a, b, c, d, e, f]
// where x' = a*x + c*y + e,  y' = b*x + d*y + f
type Matrix = [number, number, number, number, number, number];

const IDENTITY_MATRIX: Matrix = [1, 0, 0, 1, 0, 0];

function matMul(m1: Matrix, m2: Matrix): Matrix {
  const [a1, b1, c1, d1, e1, f1] = m1;
  const [a2, b2, c2, d2, e2, f2] = m2;
  return [
    a1 * a2 + c1 * b2,  b1 * a2 + d1 * b2,
    a1 * c2 + c1 * d2,  b1 * c2 + d1 * d2,
    a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1,
  ];
}

function parseSvgTransform(transformStr: string): Matrix {
  let result: Matrix = [...IDENTITY_MATRIX];
  const re = /(\w+)\s*\(([^)]*)\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(transformStr)) !== null) {
    const func = m[1];
    const args = m[2].trim().split(/[\s,]+/).filter(Boolean).map(Number);
    let mat: Matrix;
    switch (func) {
      case 'matrix':
        mat = args as unknown as Matrix;
        break;
      case 'translate': {
        const tx = args[0] ?? 0, ty = args[1] ?? 0;
        mat = [1, 0, 0, 1, tx, ty];
        break;
      }
      case 'scale': {
        const sx = args[0] ?? 1, sy = args[1] ?? sx;
        mat = [sx, 0, 0, sy, 0, 0];
        break;
      }
      case 'rotate': {
        const angle = (args[0] ?? 0) * Math.PI / 180;
        const cosA = Math.cos(angle), sinA = Math.sin(angle);
        if (args.length === 3) {
          const cx = args[1], cy = args[2];
          mat = [cosA, sinA, -sinA, cosA,
            cx - cx * cosA + cy * sinA, cy - cx * sinA - cy * cosA];
        } else {
          mat = [cosA, sinA, -sinA, cosA, 0, 0];
        }
        break;
      }
      case 'skewX': {
        mat = [1, 0, Math.tan((args[0] ?? 0) * Math.PI / 180), 1, 0, 0];
        break;
      }
      case 'skewY': {
        mat = [1, Math.tan((args[0] ?? 0) * Math.PI / 180), 0, 1, 0, 0];
        break;
      }
      default:
        continue;
    }
    result = matMul(result, mat);
  }
  return result;
}

function applyMatrix(mat: Matrix, x: number, y: number): [number, number] {
  const [a, b, c, d, e, f] = mat;
  return [a * x + c * y + e, b * x + d * y + f];
}

// ---- SVG DOM path extraction with <g> transform support ----
function extractPathsFromSvg(text: string): { d: string; matrix: Matrix }[] {
  // Parse SVG XML using DOMParser to correctly handle nested <g transform>
  const parser = new DOMParser();
  const doc = parser.parseFromString(text, 'image/svg+xml');
  const results: { d: string; matrix: Matrix }[] = [];

  function collectTransform(el: Element): Matrix {
    // Walk up the tree accumulating transforms (outermost first)
    const chain: Matrix[] = [];
    let node: Element | null = el;
    while (node && node.tagName !== 'svg') {
      const t = node.getAttribute('transform');
      if (t) chain.unshift(parseSvgTransform(t));
      node = node.parentElement;
    }
    return chain.reduce((acc, m) => matMul(acc, m), IDENTITY_MATRIX);
  }

  const paths = doc.querySelectorAll('path');
  paths.forEach(path => {
    const d = path.getAttribute('d');
    if (!d || !/[MmLlCcQqZzHhVvSsTtAa]/.test(d)) return;
    const matrix = collectTransform(path);
    results.push({ d: d.trim(), matrix });
  });
  return results;
}

function applyMatrixToCmd(cmd: PathCommand, mat: Matrix): PathCommand {
  const pt = (x: number, y: number) => applyMatrix(mat, x, y);
  if (cmd.type === 'M' || cmd.type === 'L') {
    const [x, y] = pt(cmd.x, cmd.y);
    return { ...cmd, x, y };
  }
  if (cmd.type === 'C') {
    const [x1, y1] = pt(cmd.x1, cmd.y1);
    const [x2, y2] = pt(cmd.x2, cmd.y2);
    const [x, y] = pt(cmd.x, cmd.y);
    return { ...cmd, x1, y1, x2, y2, x, y };
  }
  if (cmd.type === 'Q') {
    const [x1, y1] = pt(cmd.x1, cmd.y1);
    const [x, y] = pt(cmd.x, cmd.y);
    return { ...cmd, x1, y1, x, y };
  }
  return cmd;
}

// ---- SVG path parser ----
export type PathCommand =
  | { type: "M"; x: number; y: number }
  | { type: "L"; x: number; y: number }
  | { type: "C"; x1: number; y1: number; x2: number; y2: number; x: number; y: number }
  | { type: "Q"; x1: number; y1: number; x: number; y: number }
  | { type: "Z" };

function tokenize(d: string): string[] {
  return (
    d
      .replace(/([MmLlCcQqZzHhVvSsTtAa])/g, " $1 ")
      .trim()
      .split(/[\s,]+/)
      .filter(Boolean)
  );
}

export function parsePath(d: string): PathCommand[] {
  const tokens = tokenize(d);
  const cmds: PathCommand[] = [];
  let i = 0;
  let lastCmd = "";
  let cx = 0, cy = 0;
  let lastCtrlX = 0, lastCtrlY = 0;
  let lastWasCubic = false, lastWasQuad = false;

  const num = () => parseFloat(tokens[i++] ?? "0");

  while (i < tokens.length) {
    const t = tokens[i];
    if (/[a-zA-Z]/.test(t)) { lastCmd = t; i++; }

    const prevWasCubic = lastWasCubic;
    const prevWasQuad = lastWasQuad;
    lastWasCubic = false; lastWasQuad = false;

    switch (lastCmd) {
      case "M": { const x = num(), y = num(); cx = x; cy = y; cmds.push({ type: "M", x, y }); lastCmd = "L"; break; }
      case "m": { const x = cx + num(), y = cy + num(); cx = x; cy = y; cmds.push({ type: "M", x, y }); lastCmd = "l"; break; }
      case "L": { const x = num(), y = num(); cx = x; cy = y; cmds.push({ type: "L", x, y }); break; }
      case "l": { const x = cx + num(), y = cy + num(); cx = x; cy = y; cmds.push({ type: "L", x, y }); break; }
      case "H": { const x = num(); cx = x; cmds.push({ type: "L", x, y: cy }); break; }
      case "h": { const x = cx + num(); cx = x; cmds.push({ type: "L", x, y: cy }); break; }
      case "V": { const y = num(); cy = y; cmds.push({ type: "L", x: cx, y }); break; }
      case "v": { const y = cy + num(); cy = y; cmds.push({ type: "L", x: cx, y }); break; }
      case "C": { const x1=num(),y1=num(),x2=num(),y2=num(),x=num(),y=num(); lastCtrlX=x2; lastCtrlY=y2; cx=x; cy=y; lastWasCubic=true; cmds.push({ type:"C",x1,y1,x2,y2,x,y }); break; }
      case "c": { const ox=cx,oy=cy; const x1=ox+num(),y1=oy+num(),x2=ox+num(),y2=oy+num(),x=ox+num(),y=oy+num(); lastCtrlX=x2; lastCtrlY=y2; cx=x; cy=y; lastWasCubic=true; cmds.push({ type:"C",x1,y1,x2,y2,x,y }); break; }
      case "S": {
        const x1 = prevWasCubic ? 2*cx - lastCtrlX : cx;
        const y1 = prevWasCubic ? 2*cy - lastCtrlY : cy;
        const x2=num(),y2=num(),x=num(),y=num(); lastCtrlX=x2; lastCtrlY=y2; cx=x; cy=y; lastWasCubic=true;
        cmds.push({ type:"C",x1,y1,x2,y2,x,y }); break; }
      case "s": {
        const x1 = prevWasCubic ? 2*cx - lastCtrlX : cx;
        const y1 = prevWasCubic ? 2*cy - lastCtrlY : cy;
        const ox=cx,oy=cy; const x2=ox+num(),y2=oy+num(),x=ox+num(),y=oy+num(); lastCtrlX=x2; lastCtrlY=y2; cx=x; cy=y; lastWasCubic=true;
        cmds.push({ type:"C",x1,y1,x2,y2,x,y }); break; }
      case "Q": { const x1=num(),y1=num(),x=num(),y=num(); lastCtrlX=x1; lastCtrlY=y1; cx=x; cy=y; lastWasQuad=true; cmds.push({ type:"Q",x1,y1,x,y }); break; }
      case "q": { const ox=cx,oy=cy; const x1=ox+num(),y1=oy+num(),x=ox+num(),y=oy+num(); lastCtrlX=x1; lastCtrlY=y1; cx=x; cy=y; lastWasQuad=true; cmds.push({ type:"Q",x1,y1,x,y }); break; }
      case "T": {
        const x1 = prevWasQuad ? 2*cx - lastCtrlX : cx;
        const y1 = prevWasQuad ? 2*cy - lastCtrlY : cy;
        const x=num(),y=num(); lastCtrlX=x1; lastCtrlY=y1; cx=x; cy=y; lastWasQuad=true;
        cmds.push({ type:"Q",x1,y1,x,y }); break; }
      case "t": {
        const x1 = prevWasQuad ? 2*cx - lastCtrlX : cx;
        const y1 = prevWasQuad ? 2*cy - lastCtrlY : cy;
        const ox=cx,oy=cy; const x=ox+num(),y=oy+num(); lastCtrlX=x1; lastCtrlY=y1; cx=x; cy=y; lastWasQuad=true;
        cmds.push({ type:"Q",x1,y1,x,y }); break; }
      case "A": case "a": {
        const rel = lastCmd === "a";
        num(); num(); num(); num(); num();
        const x = rel ? cx + num() : num();
        const y = rel ? cy + num() : num();
        cx=x; cy=y; cmds.push({ type:"L",x,y }); break; }
      case "Z": case "z": { cmds.push({ type: "Z" }); break; }
      default: i++; break;
    }
    if (!lastWasCubic && !lastWasQuad) { lastCtrlX = cx; lastCtrlY = cy; }
  }
  return cmds;
}

export function serializePath(cmds: PathCommand[]): string {
  return cmds.map(c => {
    switch (c.type) {
      case "M": return `M ${c.x} ${c.y}`;
      case "L": return `L ${c.x} ${c.y}`;
      case "C": return `C ${c.x1} ${c.y1} ${c.x2} ${c.y2} ${c.x} ${c.y}`;
      case "Q": return `Q ${c.x1} ${c.y1} ${c.x} ${c.y}`;
      case "Z": return "Z";
    }
  }).join(" ");
}

// ---- Bounding box ----
export type BBox = { minX: number; minY: number; maxX: number; maxY: number };

export function computeBBox(cmds: PathCommand[]): BBox | null {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  let hasPoints = false;
  const expand = (x: number, y: number) => {
    hasPoints = true;
    minX = Math.min(minX, x); minY = Math.min(minY, y);
    maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
  };
  cmds.forEach(c => {
    if (c.type === "M" || c.type === "L") expand(c.x, c.y);
    else if (c.type === "C") { expand(c.x1, c.y1); expand(c.x2, c.y2); expand(c.x, c.y); }
    else if (c.type === "Q") { expand(c.x1, c.y1); expand(c.x, c.y); }
  });
  if (!hasPoints) return null;
  return { minX, minY, maxX, maxY };
}

// Apply translate + scale transform to all path commands
export function transformCmds(
  cmds: PathCommand[],
  dx: number, dy: number,
  scaleX: number, scaleY: number,
  originX: number, originY: number
): PathCommand[] {
  const tx = (x: number) => originX + (x - originX) * scaleX + dx;
  const ty = (y: number) => originY + (y - originY) * scaleY + dy;
  return cmds.map(c => {
    if (c.type === "M") return { ...c, x: tx(c.x), y: ty(c.y) };
    if (c.type === "L") return { ...c, x: tx(c.x), y: ty(c.y) };
    if (c.type === "C") return { ...c, x1: tx(c.x1), y1: ty(c.y1), x2: tx(c.x2), y2: ty(c.y2), x: tx(c.x), y: ty(c.y) };
    if (c.type === "Q") return { ...c, x1: tx(c.x1), y1: ty(c.y1), x: tx(c.x), y: ty(c.y) };
    return c;
  }) as PathCommand[];
}

// ---- Node extraction ----
export type NodePoint = {
  cmdIndex: number;
  role: "anchor" | "ctrl1" | "ctrl2";
  x: number;
  y: number;
};

export function extractNodes(cmds: PathCommand[]): NodePoint[] {
  const nodes: NodePoint[] = [];
  cmds.forEach((c, i) => {
    if (c.type === "M" || c.type === "L") {
      nodes.push({ cmdIndex: i, role: "anchor", x: c.x, y: c.y });
    } else if (c.type === "C") {
      nodes.push({ cmdIndex: i, role: "ctrl1", x: c.x1, y: c.y1 });
      nodes.push({ cmdIndex: i, role: "ctrl2", x: c.x2, y: c.y2 });
      nodes.push({ cmdIndex: i, role: "anchor", x: c.x, y: c.y });
    } else if (c.type === "Q") {
      nodes.push({ cmdIndex: i, role: "ctrl1", x: c.x1, y: c.y1 });
      nodes.push({ cmdIndex: i, role: "anchor", x: c.x, y: c.y });
    }
  });
  return nodes;
}

// ---- Path operation utilities ----

/**
 * cleanupPath: Remove duplicate points, degenerate segments (zero-length lines),
 * and redundant Z commands. Returns cleaned PathCommand[].
 */
export function cleanupPath(cmds: PathCommand[]): PathCommand[] {
  const result: PathCommand[] = [];
  let lastX = 0, lastY = 0;
  let subpathStartX = 0, subpathStartY = 0;
  const EPS = 0.01;
  for (let i = 0; i < cmds.length; i++) {
    const c = cmds[i];
    if (c.type === "M") {
      subpathStartX = c.x; subpathStartY = c.y;
      lastX = c.x; lastY = c.y;
      result.push(c);
    } else if (c.type === "L") {
      if (Math.abs(c.x - lastX) < EPS && Math.abs(c.y - lastY) < EPS) continue; // skip zero-length
      lastX = c.x; lastY = c.y;
      result.push(c);
    } else if (c.type === "C") {
      if (Math.abs(c.x - lastX) < EPS && Math.abs(c.y - lastY) < EPS &&
          Math.abs(c.x1 - lastX) < EPS && Math.abs(c.y1 - lastY) < EPS &&
          Math.abs(c.x2 - lastX) < EPS && Math.abs(c.y2 - lastY) < EPS) continue;
      lastX = c.x; lastY = c.y;
      result.push(c);
    } else if (c.type === "Q") {
      if (Math.abs(c.x - lastX) < EPS && Math.abs(c.y - lastY) < EPS &&
          Math.abs(c.x1 - lastX) < EPS && Math.abs(c.y1 - lastY) < EPS) continue;
      lastX = c.x; lastY = c.y;
      result.push(c);
    } else if (c.type === "Z") {
      // Skip redundant Z (already at subpath start)
      if (Math.abs(lastX - subpathStartX) < EPS && Math.abs(lastY - subpathStartY) < EPS) {
        // still emit Z to close the subpath
      }
      lastX = subpathStartX; lastY = subpathStartY;
      result.push(c);
    }
  }
  return result;
}

/**
 * simplifyPath: Reduce point count using Ramer-Douglas-Peucker on L segments.
 * tolerance: distance threshold in font units (default 2). Higher = more aggressive.
 * Cubic/Quadratic segments are kept as-is (only L segments are simplified).
 */
export function simplifyPath(cmds: PathCommand[], tolerance = 2): PathCommand[] {
  // Split into subpaths, simplify L-only runs within each subpath
  const result: PathCommand[] = [];

  function rdp(pts: { x: number; y: number; cmd: PathCommand }[], start: number, end: number, tol: number, keep: Set<number>) {
    if (end <= start + 1) return;
    let maxDist = 0, maxIdx = start;
    const x1 = pts[start].x, y1 = pts[start].y;
    const x2 = pts[end].x, y2 = pts[end].y;
    const dx = x2 - x1, dy = y2 - y1;
    const len = Math.sqrt(dx * dx + dy * dy);
    for (let i = start + 1; i < end; i++) {
      let dist: number;
      if (len < 1e-10) {
        dist = Math.sqrt((pts[i].x - x1) ** 2 + (pts[i].y - y1) ** 2);
      } else {
        dist = Math.abs(dy * pts[i].x - dx * pts[i].y + x2 * y1 - y2 * x1) / len;
      }
      if (dist > maxDist) { maxDist = dist; maxIdx = i; }
    }
    if (maxDist > tol) {
      keep.add(maxIdx);
      rdp(pts, start, maxIdx, tol, keep);
      rdp(pts, maxIdx, end, tol, keep);
    }
  }

  // Process subpaths
  let i = 0;
  while (i < cmds.length) {
    if (cmds[i].type !== "M") { result.push(cmds[i]); i++; continue; }
    // Collect this subpath
    const subStart = i;
    i++;
    const sub: PathCommand[] = [cmds[subStart]];
    while (i < cmds.length && cmds[i].type !== "M") {
      sub.push(cmds[i]); i++;
    }
    // Find runs of consecutive L commands
    let j = 0;
    while (j < sub.length) {
      const c = sub[j];
      if (c.type !== "L") { result.push(c); j++; continue; }
      // Collect L run
      const runStart = j - 1; // previous anchor
      const pts: { x: number; y: number; cmd: PathCommand }[] = [];
      // Previous anchor
      const prev = sub[j - 1];
      if (prev && (prev.type === "M" || prev.type === "L")) {
        pts.push({ x: prev.x, y: prev.y, cmd: prev });
      } else {
        result.push(c); j++; continue;
      }
      const runCmds: PathCommand[] = [];
      while (j < sub.length && sub[j].type === "L") {
        const lc = sub[j] as { type: "L"; x: number; y: number };
        pts.push({ x: lc.x, y: lc.y, cmd: sub[j] });
        runCmds.push(sub[j]);
        j++;
      }
      if (pts.length < 3) { runCmds.forEach(c => result.push(c)); continue; }
      const keep = new Set<number>([0, pts.length - 1]);
      rdp(pts, 0, pts.length - 1, tolerance, keep);
      for (let k = 1; k < pts.length; k++) {
        if (keep.has(k)) result.push(runCmds[k - 1]);
      }
    }
  }
  return result;
}

/**
 * smoothPath: Convert sharp L segments to smooth C (cubic Bezier) curves.
 * tension: 0=no smoothing, 1=maximum (default 0.3).
 * Only converts runs of L commands; M/C/Q/Z are preserved.
 */
export function smoothPath(cmds: PathCommand[], tension = 0.3): PathCommand[] {
  const result: PathCommand[] = [];
  for (let i = 0; i < cmds.length; i++) {
    const c = cmds[i];
    if (c.type !== "L") { result.push(c); continue; }
    // Get prev and next anchor points
    const prev = cmds[i - 1];
    const next = cmds[i + 1];
    if (!prev || (prev.type !== "M" && prev.type !== "L" && prev.type !== "C" && prev.type !== "Q")) {
      result.push(c); continue;
    }
    const px = prev.type === "C" ? prev.x : prev.type === "Q" ? prev.x : prev.x;
    const py = prev.type === "C" ? prev.y : prev.type === "Q" ? prev.y : prev.y;
    const nx = next && (next.type === "L" || next.type === "M") ? next.x : c.x;
    const ny = next && (next.type === "L" || next.type === "M") ? next.y : c.y;
    // Catmull-Rom to Bezier
    const x1 = px + (c.x - px) * tension + (c.x - nx) * tension * 0.1;
    const y1 = py + (c.y - py) * tension + (c.y - ny) * tension * 0.1;
    const x2 = c.x - (nx - px) * tension * 0.5;
    const y2 = c.y - (ny - py) * tension * 0.5;
    result.push({ type: "C", x1, y1, x2, y2, x: c.x, y: c.y });
  }
  return result;
}

function updateCmdWithNode(cmd: PathCommand, role: NodePoint["role"], nx: number, ny: number): PathCommand {
  if (cmd.type === "M" || cmd.type === "L") return { ...cmd, x: nx, y: ny };
  if (cmd.type === "C") {
    if (role === "ctrl1") return { ...cmd, x1: nx, y1: ny };
    if (role === "ctrl2") return { ...cmd, x2: nx, y2: ny };
    return { ...cmd, x: nx, y: ny };
  }
  if (cmd.type === "Q") {
    if (role === "ctrl1") return { ...cmd, x1: nx, y1: ny };
    return { ...cmd, x: nx, y: ny };
  }
  return cmd;
}

// ---- Canvas drawing ----
export type EditMode = "node" | "transform";

interface GlyphCanvasProps {
  svgUrl: string;
  pathData?: string | null;
  glyphId?: number | null;
  char: string;
  upm: number;
  ascender: number;
  descender: number;
  xHeight?: number;
  capHeight?: number;
  advanceWidth: number;
  onPathChange?: (newPath: string) => void;
  onWidthChange?: (newWidth: number) => void;
  onBBoxChange?: (bbox: BBox | null) => void;
  editMode?: EditMode;
  readonly?: boolean;
  /** External zoom level (0.2-8). When provided, overrides internal zoom state. */
  zoomLevel?: number;
  /** Called when zoom changes internally (wheel / ± buttons) so parent can sync slider */
  onZoomChange?: (zoom: number) => void;
}

const PADDING = 60;
const GUIDE_COLOR = "rgba(0,120,255,0.25)";
const BASELINE_COLOR = "rgba(0,120,255,0.5)";
const ANCHOR_COLOR = "#1a56db";
const CTRL_COLOR = "#e02424";
const HANDLE_LINE_COLOR = "rgba(224,36,36,0.4)";
const ANCHOR_R = 5;
const CTRL_R = 4;
const BBOX_COLOR = "rgba(255,140,0,0.85)";
const BBOX_FILL = "rgba(255,140,0,0.06)";

// 8 scale handles: corners + midpoints
type HandlePos = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";
const HANDLE_POSITIONS: HandlePos[] = ["nw","n","ne","e","se","s","sw","w"];

export default function GlyphCanvas({
  svgUrl,
  pathData,
  glyphId,
  char,
  upm,
  ascender,
  descender,
  xHeight = 500,
  capHeight = 700,
  advanceWidth,
  onPathChange,
  onWidthChange,
  onBBoxChange,
  editMode = "node",
  readonly = false,
  zoomLevel,
  onZoomChange,
}: GlyphCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoomInternal, setZoomInternal] = useState(1);
  const zoom = zoomLevel !== undefined ? zoomLevel : zoomInternal;
  const setZoom = (updater: number | ((prev: number) => number)) => {
    const next = typeof updater === "function" ? updater(zoom) : updater;
    const clamped = Math.max(0.2, Math.min(8, next));
    setZoomInternal(clamped);
    onZoomChange?.(clamped);
  };
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [cmds, setCmds] = useState<PathCommand[]>([]);
  const [ghostImg, setGhostImg] = useState<HTMLImageElement | null>(null);
  const [dragging, setDragging] = useState<{ nodeIdx: number } | null>(null);
  const [draggingWidth, setDraggingWidth] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ w: 600, h: 600 });
  const [isPanning, setIsPanning] = useState(false);
  const panStart = useRef<{ mx: number; my: number; px: number; py: number } | null>(null);

  // Transform mode state
  const [draggingGlyph, setDraggingGlyph] = useState(false);
  const [draggingHandle, setDraggingHandle] = useState<HandlePos | null>(null);
  const transformStart = useRef<{
    mx: number; my: number;
    cmds: PathCommand[];
    bbox: BBox;
    lockAspect: boolean;
  } | null>(null);
  const [lockAspect, setLockAspect] = useState(false);

  // Load ghost image
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => setGhostImg(img);
    img.src = svgUrl;
  }, [svgUrl]);

  // Parse path data
  useEffect(() => {
    if (pathData != null) {
      // pathData='' means explicitly empty glyph (reset), pathData=null means not yet loaded
      setCmds(pathData ? parsePath(pathData) : []);
    } else {
      fetch(svgUrl)
        .then(r => r.text())
        .then(text => {
          // Use DOMParser to extract paths with full <g transform> support
          const pathEntries = extractPathsFromSvg(text);
          if (pathEntries.length === 0) return;

          // Parse each path's d attribute, then apply its accumulated transform matrix
          const rawCmdsForBBox: PathCommand[] = [];
          for (const { d, matrix } of pathEntries) {
            const cmdsForPath = parsePath(d);
            // Check if matrix is identity (avoid unnecessary work)
            const isIdentity = matrix[0]===1 && matrix[1]===0 && matrix[2]===0 &&
                               matrix[3]===1 && matrix[4]===0 && matrix[5]===0;
            if (isIdentity) {
              rawCmdsForBBox.push(...cmdsForPath);
            } else {
              rawCmdsForBBox.push(...cmdsForPath.map(c => applyMatrixToCmd(c, matrix)));
            }
          }

          // Always compute bounding box from actual path data (ignores SVG viewBox padding/margins)
          // This correctly handles SVGs with large whitespace (e.g. A4-sized canvas with small glyph)
          let minX=Infinity, maxX=-Infinity, minY=Infinity, maxY=-Infinity;
          rawCmdsForBBox.forEach(c => {
            if (c.type === 'M' || c.type === 'L') {
              minX=Math.min(minX,c.x); maxX=Math.max(maxX,c.x);
              minY=Math.min(minY,c.y); maxY=Math.max(maxY,c.y);
            } else if (c.type === 'C') {
              minX=Math.min(minX,c.x,c.x1,c.x2); maxX=Math.max(maxX,c.x,c.x1,c.x2);
              minY=Math.min(minY,c.y,c.y1,c.y2); maxY=Math.max(maxY,c.y,c.y1,c.y2);
            } else if (c.type === 'Q') {
              minX=Math.min(minX,c.x,c.x1); maxX=Math.max(maxX,c.x,c.x1);
              minY=Math.min(minY,c.y,c.y1); maxY=Math.max(maxY,c.y,c.y1);
            }
          });
          if (!isFinite(minX) || !isFinite(minY)) return;
          const svgX = minX, svgY = minY;
          const svgW = maxX - minX;
          const svgH = maxY - minY;
          if (svgW <= 0 || svgH <= 0) return;

          const fontH = ascender - descender;
          const scaleY = fontH / svgH;
          // Scale by height only (fit to font height), preserve aspect ratio
          const scale = scaleY;

          // Compute actual glyph width after scaling
          const scaledW = svgW * scale;
          // Small side bearing (5% of scaled width, min 20 units)
          const sideBearing = Math.max(20, Math.round(scaledW * 0.05));
          // Auto advance width = glyph width + 2 side bearings
          const autoAdvanceWidth = Math.round(scaledW + sideBearing * 2);
          // Left bearing offset
          const offsetX = sideBearing;

          const normalizedCmds = rawCmdsForBBox.map(c => {
            const nx = (x: number) => (x - svgX) * scale + offsetX;
            const ny = (y: number) => ascender - (y - svgY) * scale;
            if (c.type === 'M') return { ...c, x: nx(c.x), y: ny(c.y) };
            if (c.type === 'L') return { ...c, x: nx(c.x), y: ny(c.y) };
            if (c.type === 'C') return { ...c, x1: nx(c.x1), y1: ny(c.y1), x2: nx(c.x2), y2: ny(c.y2), x: nx(c.x), y: ny(c.y) };
            if (c.type === 'Q') return { ...c, x1: nx(c.x1), y1: ny(c.y1), x: nx(c.x), y: ny(c.y) };
            return c;
          }) as PathCommand[];

          setCmds(normalizedCmds);
          const newPath = serializePath(normalizedCmds);
          onPathChange?.(newPath);
          // Update advance width to match actual glyph width
          onWidthChange?.(autoAdvanceWidth);
        })
        .catch(() => {});
    }
  // NOTE: advanceWidth intentionally excluded from deps - normalization computes and emits new width via onWidthChange
  // glyphId is included so that replacing a glyph with a new upload (same unicode) forces re-normalization
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [svgUrl, pathData, glyphId, upm, ascender, descender]);

  // Notify parent of bbox changes
  const bbox = useMemo(() => computeBBox(cmds), [cmds]);
  useEffect(() => { onBBoxChange?.(bbox); }, [bbox, onBBoxChange]);

  // Resize observer
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      const e = entries[0];
      if (e) setCanvasSize({ w: e.contentRect.width, h: e.contentRect.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const fontH = useMemo(() => ascender - descender, [ascender, descender]);

  const toCanvas = useCallback((fx: number, fy: number) => {
    const availW = canvasSize.w - PADDING * 2;
    const availH = canvasSize.h - PADDING * 2;
    const scale = Math.min(availW / upm, availH / fontH) * zoom;
    const originX = PADDING + pan.x + (availW - upm * scale) / 2;
    const originY = PADDING + pan.y + (availH - fontH * scale) / 2 + ascender * scale;
    return { x: originX + fx * scale, y: originY - fy * scale, scale };
  }, [canvasSize, upm, fontH, ascender, zoom, pan]);

  const toFont = useCallback((cx: number, cy: number) => {
    const { x: ox, y: oy, scale } = toCanvas(0, 0);
    return { x: (cx - ox) / scale, y: (oy - cy) / scale };
  }, [toCanvas]);

  const nodes = useMemo(() => extractNodes(cmds), [cmds]);

  // Compute canvas-space bbox handles
  const bboxHandles = useMemo(() => {
    if (!bbox) return null;
    const tl = toCanvas(bbox.minX, bbox.maxY);
    const br = toCanvas(bbox.maxX, bbox.minY);
    const cx = (tl.x + br.x) / 2;
    const cy = (tl.y + br.y) / 2;
    return {
      nw: { x: tl.x, y: tl.y },
      n:  { x: cx,   y: tl.y },
      ne: { x: br.x, y: tl.y },
      e:  { x: br.x, y: cy   },
      se: { x: br.x, y: br.y },
      s:  { x: cx,   y: br.y },
      sw: { x: tl.x, y: br.y },
      w:  { x: tl.x, y: cy   },
      tl, br, cx, cy,
    };
  }, [bbox, toCanvas]);

  // Draw
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvasSize.w;
    canvas.height = canvasSize.h;
    ctx.clearRect(0, 0, canvasSize.w, canvasSize.h);

    const { scale } = toCanvas(0, 0);

    // Guidelines
    const drawHLine = (fy: number, color: string, dash: number[] = []) => {
      const { y } = toCanvas(0, fy);
      ctx.save();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash(dash);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvasSize.w, y);
      ctx.stroke();
      ctx.restore();
    };
    drawHLine(ascender, GUIDE_COLOR, [4, 4]);
    drawHLine(capHeight, GUIDE_COLOR, [4, 4]);
    drawHLine(xHeight, GUIDE_COLOR, [4, 4]);
    drawHLine(0, BASELINE_COLOR);
    drawHLine(descender, GUIDE_COLOR, [4, 4]);

    // Advance width line
    const { x: awX } = toCanvas(advanceWidth, 0);
    ctx.save();
    ctx.strokeStyle = "rgba(0,180,0,0.4)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 3]);
    ctx.beginPath();
    ctx.moveTo(awX, 0);
    ctx.lineTo(awX, canvasSize.h);
    ctx.stroke();
    const { y: baseY } = toCanvas(0, 0);
    ctx.fillStyle = "rgba(0,180,0,0.7)";
    ctx.fillRect(awX - 6, baseY - 10, 12, 20);
    ctx.fillStyle = "white";
    ctx.font = "bold 9px monospace";
    ctx.textAlign = "center";
    ctx.fillText("AW", awX, baseY + 4);
    ctx.restore();

    // Left bearing line
    const { x: lbX } = toCanvas(0, 0);
    ctx.save();
    ctx.strokeStyle = "rgba(0,0,0,0.12)";
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(lbX, 0);
    ctx.lineTo(lbX, canvasSize.h);
    ctx.stroke();
    ctx.restore();

    // Guideline labels
    ctx.save();
    ctx.font = "10px monospace";
    ctx.fillStyle = "rgba(0,120,255,0.5)";
    ctx.textAlign = "left";
    const labels: [number, string][] = [
      [ascender, "ascender"], [capHeight, "cap-height"],
      [xHeight, "x-height"], [0, "baseline"], [descender, "descender"],
    ];
    labels.forEach(([fy, label]) => {
      const { y } = toCanvas(0, fy);
      ctx.fillText(label, 4, y - 2);
    });
    ctx.restore();

    // Reference font silhouette
    {
      const { y: refY } = toCanvas(0, 0);
      // Use full font height (ascender to descender) for correct proportional sizing
      const glyphH = fontH * scale;
      const fontSize = Math.max(12, glyphH);
      ctx.save();
      ctx.font = `${fontSize}px "Hiragino Sans", "Yu Gothic", "Noto Sans JP", sans-serif, serif`;
      ctx.fillStyle = "rgba(0,0,0,0.07)";
      ctx.textBaseline = "alphabetic";
      // Measure text width and center within advance width
      const textW = ctx.measureText(char).width;
      const { x: awLeft } = toCanvas(0, 0);
      const { x: awRight } = toCanvas(advanceWidth, 0);
      const awCanvasW = awRight - awLeft;
      const refX = awLeft + (awCanvasW - textW) / 2;
      ctx.fillText(char, refX, refY);
      ctx.restore();
    }

    // Ghost SVG image
    if (ghostImg) {
      const { x: gx, y: gy } = toCanvas(0, ascender);
      ctx.save();
      ctx.globalAlpha = 0.06;
      ctx.drawImage(ghostImg, gx, gy, advanceWidth * scale, fontH * scale);
      ctx.restore();
    }

    // Glyph path
    if (cmds.length > 0) {
      ctx.save();
      ctx.beginPath();
      cmds.forEach(c => {
        if (c.type === "M") { const p = toCanvas(c.x, c.y); ctx.moveTo(p.x, p.y); }
        else if (c.type === "L") { const p = toCanvas(c.x, c.y); ctx.lineTo(p.x, p.y); }
        else if (c.type === "C") {
          const p1 = toCanvas(c.x1, c.y1), p2 = toCanvas(c.x2, c.y2), p = toCanvas(c.x, c.y);
          ctx.bezierCurveTo(p1.x, p1.y, p2.x, p2.y, p.x, p.y);
        }
        else if (c.type === "Q") {
          const p1 = toCanvas(c.x1, c.y1), p = toCanvas(c.x, c.y);
          ctx.quadraticCurveTo(p1.x, p1.y, p.x, p.y);
        }
        else if (c.type === "Z") { ctx.closePath(); }
      });
      ctx.fillStyle = "rgba(0,0,0,0.85)";
      ctx.fill("evenodd");
      ctx.strokeStyle = "rgba(0,0,0,0.3)";
      ctx.lineWidth = 0.5;
      ctx.stroke();
      ctx.restore();
    }

    if (readonly) return;

    // ---- Transform mode: bounding box + handles ----
    if (editMode === "transform" && bboxHandles) {
      const { tl, br } = bboxHandles;
      // Fill
      ctx.save();
      ctx.fillStyle = BBOX_FILL;
      ctx.fillRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
      // Border
      ctx.strokeStyle = BBOX_COLOR;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
      ctx.restore();

      // Scale handles
      HANDLE_POSITIONS.forEach(pos => {
        const h = bboxHandles[pos];
        ctx.save();
        ctx.fillStyle = "white";
        ctx.strokeStyle = BBOX_COLOR;
        ctx.lineWidth = 2;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.rect(h.x - 5, h.y - 5, 10, 10);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      });
    }

    // ---- Node mode: control handles and nodes ----
    if (editMode === "node") {
      nodes.forEach((node) => {
        const p = toCanvas(node.x, node.y);
        if (node.role === "ctrl1" || node.role === "ctrl2") {
          const anchorNode = nodes.find(n => n.cmdIndex === node.cmdIndex && n.role === "anchor");
          if (anchorNode) {
            const ap = toCanvas(anchorNode.x, anchorNode.y);
            ctx.save();
            ctx.strokeStyle = HANDLE_LINE_COLOR;
            ctx.lineWidth = 1;
            ctx.setLineDash([2, 2]);
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(ap.x, ap.y);
            ctx.stroke();
            ctx.restore();
          }
          ctx.save();
          ctx.fillStyle = CTRL_COLOR;
          ctx.strokeStyle = "white";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(p.x, p.y, CTRL_R, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        } else {
          ctx.save();
          ctx.fillStyle = ANCHOR_COLOR;
          ctx.strokeStyle = "white";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.rect(p.x - ANCHOR_R, p.y - ANCHOR_R, ANCHOR_R * 2, ANCHOR_R * 2);
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        }
      });
    }
  }, [cmds, nodes, ghostImg, canvasSize, toCanvas, advanceWidth, ascender, descender, capHeight, xHeight, fontH, upm, zoom, pan, readonly, editMode, bboxHandles, char]);

  // Hit tests
  const hitTestNode = useCallback((mx: number, my: number) => {
    for (let i = nodes.length - 1; i >= 0; i--) {
      const p = toCanvas(nodes[i].x, nodes[i].y);
      const r = nodes[i].role === "anchor" ? ANCHOR_R + 3 : CTRL_R + 3;
      if (Math.abs(mx - p.x) <= r && Math.abs(my - p.y) <= r) return i;
    }
    return -1;
  }, [nodes, toCanvas]);

  const hitTestWidth = useCallback((mx: number, my: number) => {
    const { x: awX, y: baseY } = toCanvas(advanceWidth, 0);
    return Math.abs(mx - awX) <= 8 && Math.abs(my - baseY) <= 12;
  }, [toCanvas, advanceWidth]);

  const hitTestHandle = useCallback((mx: number, my: number): HandlePos | null => {
    if (!bboxHandles) return null;
    for (const pos of HANDLE_POSITIONS) {
      const h = bboxHandles[pos];
      if (Math.abs(mx - h.x) <= 7 && Math.abs(my - h.y) <= 7) return pos;
    }
    return null;
  }, [bboxHandles]);

  const hitTestGlyph = useCallback((mx: number, my: number): boolean => {
    if (!bboxHandles) return false;
    const { tl, br } = bboxHandles;
    return mx >= tl.x && mx <= br.x && my >= tl.y && my <= br.y;
  }, [bboxHandles]);

  const getPos = (e: React.MouseEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (readonly) return;
    const { x, y } = getPos(e);

    // Pan: middle button or alt+left
    if (e.button === 1 || (e.button === 0 && e.altKey)) {
      setIsPanning(true);
      panStart.current = { mx: x, my: y, px: pan.x, py: pan.y };
      return;
    }

    // Advance width drag (both modes)
    if (hitTestWidth(x, y)) {
      setDraggingWidth(true);
      return;
    }

    if (editMode === "transform" && bbox) {
      // Check scale handles first
      const handle = hitTestHandle(x, y);
      if (handle) {
        setDraggingHandle(handle);
        transformStart.current = { mx: x, my: y, cmds: [...cmds], bbox, lockAspect };
        return;
      }
      // Check glyph body for move
      if (hitTestGlyph(x, y)) {
        setDraggingGlyph(true);
        transformStart.current = { mx: x, my: y, cmds: [...cmds], bbox, lockAspect };
        return;
      }
    }

    if (editMode === "node") {
      const idx = hitTestNode(x, y);
      if (idx >= 0) setDragging({ nodeIdx: idx });
    }
  }, [readonly, editMode, bbox, cmds, lockAspect, hitTestWidth, hitTestHandle, hitTestGlyph, hitTestNode, pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (readonly) return;
    const { x, y } = getPos(e);

    if (isPanning && panStart.current) {
      setPan({ x: panStart.current.px + x - panStart.current.mx, y: panStart.current.py + y - panStart.current.my });
      return;
    }

    if (draggingWidth) {
      const fp = toFont(x, y);
      onWidthChange?.(Math.max(50, Math.round(fp.x)));
      return;
    }

    // Move glyph
    if (draggingGlyph && transformStart.current) {
      const { mx, my, cmds: origCmds } = transformStart.current;
      const { scale } = toCanvas(0, 0);
      const dx = (x - mx) / scale;
      const dy = -(y - my) / scale; // flip Y
      const newCmds = transformCmds(origCmds, dx, dy, 1, 1, 0, 0);
      setCmds(newCmds);
      return;
    }

    // Scale glyph via handle
    if (draggingHandle && transformStart.current) {
      const { mx, my, cmds: origCmds, bbox: origBBox } = transformStart.current;
      const { scale } = toCanvas(0, 0);
      const ddx = (x - mx) / scale;
      const ddy = -(y - my) / scale;

      const bw = origBBox.maxX - origBBox.minX;
      const bh = origBBox.maxY - origBBox.minY;
      if (bw === 0 || bh === 0) return;

      let scaleX = 1, scaleY = 1;
      let originX = origBBox.minX, originY = origBBox.minY;

      const h = draggingHandle;
      // Determine scale factors based on which handle
      if (h.includes("e")) { scaleX = (bw + ddx) / bw; originX = origBBox.minX; }
      if (h.includes("w")) { scaleX = (bw - ddx) / bw; originX = origBBox.maxX; }
      if (h.includes("n")) { scaleY = (bh + ddy) / bh; originY = origBBox.minY; }
      if (h.includes("s")) { scaleY = (bh - ddy) / bh; originY = origBBox.maxY; }

      scaleX = Math.max(0.05, scaleX);
      scaleY = Math.max(0.05, scaleY);

      if (transformStart.current.lockAspect) {
        const avg = (Math.abs(scaleX) + Math.abs(scaleY)) / 2;
        scaleX = avg * Math.sign(scaleX);
        scaleY = avg * Math.sign(scaleY);
      }

      const newCmds = transformCmds(origCmds, 0, 0, scaleX, scaleY, originX, originY);
      setCmds(newCmds);
      return;
    }

    // Node editing
    if (dragging && editMode === "node") {
      const node = nodes[dragging.nodeIdx];
      if (!node) return;
      const fp = toFont(x, y);
      const newCmds = cmds.map((c, i) =>
        i === node.cmdIndex ? updateCmdWithNode(c, node.role, fp.x, fp.y) : c
      );
      setCmds(newCmds);
    }
  }, [readonly, isPanning, draggingWidth, draggingGlyph, draggingHandle, dragging, editMode, nodes, cmds, toFont, toCanvas, onWidthChange]);

  const handleMouseUp = useCallback(() => {
    if (dragging || draggingGlyph || draggingHandle) {
      const newPath = serializePath(cmds);
      onPathChange?.(newPath);
    }
    setDragging(null);
    setDraggingGlyph(false);
    setDraggingHandle(null);
    setDraggingWidth(false);
    setIsPanning(false);
    panStart.current = null;
    transformStart.current = null;
  }, [dragging, draggingGlyph, draggingHandle, cmds, onPathChange]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(z => Math.max(0.2, Math.min(8, z * delta)));
  }, []);

  const cursor = useMemo(() => {
    if (isPanning) return "grabbing";
    if (draggingWidth) return "ew-resize";
    if (draggingGlyph) return "grabbing";
    if (draggingHandle) return "nwse-resize";
    if (editMode === "transform") return "default";
    return "crosshair";
  }, [isPanning, draggingWidth, draggingGlyph, draggingHandle, editMode]);

  // Expose lockAspect setter for parent
  const lockAspectRef = useRef(lockAspect);
  lockAspectRef.current = lockAspect;

  return (
    <div ref={containerRef} className="w-full h-full relative select-none" style={{ background: "#fafafa" }}>
      <canvas
        ref={canvasRef}
        style={{ display: "block", width: "100%", height: "100%", cursor }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      />
      {/* Zoom controls */}
      <div className="absolute bottom-3 right-3 flex items-center gap-1">
        <button
          onClick={() => setZoom(z => Math.max(0.2, z / 1.25))}
          className="w-7 h-7 border-2 border-black bg-white font-black text-sm hover:bg-black hover:text-white transition-colors flex items-center justify-center"
        >−</button>
        <span className="font-mono text-xs px-2 bg-white border-2 border-black min-w-[52px] text-center">
          {Math.round(zoom * 100)}%
        </span>
        <button
          onClick={() => setZoom(z => Math.min(8, z * 1.25))}
          className="w-7 h-7 border-2 border-black bg-white font-black text-sm hover:bg-black hover:text-white transition-colors flex items-center justify-center"
        >+</button>
        <button
          onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
          className="w-7 h-7 border-2 border-black bg-white font-black text-xs hover:bg-black hover:text-white transition-colors flex items-center justify-center ml-1"
          title="Reset view"
        >⌂</button>
      </div>
      {/* Instructions */}
      {!readonly && (
        <div className="absolute top-2 left-2 text-[10px] font-mono text-gray-400 leading-tight pointer-events-none">
          {editMode === "node" ? (
            <>
              <div>Drag nodes to edit</div>
              <div>Alt+drag / scroll to pan/zoom</div>
              <div>Drag green AW bar to resize</div>
            </>
          ) : (
            <>
              <div>Drag glyph to move</div>
              <div>Drag orange handles to scale</div>
              <div>Alt+drag / scroll to pan/zoom</div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
