import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { ArrowRight, Type, Upload, Download } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const handleStart = () => {
    if (isAuthenticated) {
      navigate("/projects");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen bg-white text-black overflow-x-hidden">
      {/* Nav */}
      <nav className="border-b-4 border-black px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-black flex items-center justify-center">
            <Type className="w-5 h-5 text-white" />
          </div>
          <span className="font-black text-xl tracking-tight uppercase">SVG Font Maker</span>
        </div>
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <button onClick={() => navigate("/projects")} className="brutal-btn text-sm">
              My Projects
            </button>
          ) : (
            <button onClick={handleStart} className="brutal-btn text-sm">
              Sign In
            </button>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="px-8 pt-20 pb-16 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div>
            <div className="brutal-tag mb-6">Custom Font Generator</div>
            <h1 className="text-7xl lg:text-9xl font-black leading-none tracking-tighter uppercase mb-8">
              MAKE<br />
              <span className="inline-block border-b-8 border-black">YOUR</span><br />
              FONT.
            </h1>
            <p className="text-xl font-medium text-gray-600 max-w-md mb-10 leading-relaxed">
              Upload individual SVG files per character. Generate professional TTF and OTF fonts. Preview in real-time. Zero design tools required.
            </p>
            <button onClick={handleStart} className="brutal-btn text-base gap-3">
              Start Building <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          {/* Feature grid */}
          <div className="grid grid-cols-2 gap-0 border-3 border-black brutal-shadow-lg mt-8 lg:mt-0">
            {[
              { icon: Upload, label: "Upload SVGs", desc: "One file per character. A–Z, a–z, 0–9, symbols." },
              { icon: Type, label: "Build Glyphs", desc: "Automatic SVG path parsing via fonttools." },
              { icon: Download, label: "Export TTF/OTF", desc: "Industry-standard font formats, ready to use." },
              { icon: Type, label: "Live Preview", desc: "Type text and see your font in real-time." },
            ].map((f, i) => (
              <div key={i} className={`p-6 border-black ${i % 2 === 0 ? "border-r-3" : ""} ${i < 2 ? "border-b-3" : ""}`}>
                <div className="w-10 h-10 bg-black flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5 text-white" />
                </div>
                <div className="font-black text-sm uppercase tracking-widest mb-2">{f.label}</div>
                <div className="text-sm text-gray-600 leading-relaxed">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="border-t-4 border-black mx-8" />

      {/* How it works */}
      <section className="px-8 py-20 max-w-7xl mx-auto">
        <div className="flex items-end gap-6 mb-16">
          <h2 className="text-5xl font-black uppercase tracking-tighter">How It Works</h2>
          <div className="h-1 flex-1 bg-black mb-3" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border-3 border-black brutal-shadow-lg">
          {[
            { step: "01", title: "Upload SVGs", desc: "Create a font project and upload one SVG file per character. Supports uppercase, lowercase, digits, and symbols." },
            { step: "02", title: "Configure", desc: "Set font name, author, UPM, ascender/descender values. Fine-tune the metrics to match your design intent." },
            { step: "03", title: "Generate & Download", desc: "Click generate to build your TTF or OTF font. Preview it live, then download and install." },
          ].map((s, i) => (
            <div key={i} className={`p-8 ${i < 2 ? "border-r-3 border-black" : ""}`}>
              <div className="text-8xl font-black text-gray-100 leading-none mb-4 select-none">{s.step}</div>
              <div className="font-black text-lg uppercase tracking-widest mb-3 border-b-3 border-black pb-3">{s.title}</div>
              <p className="text-gray-600 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-8 mb-20 bg-black text-white p-12 brutal-shadow-lg border-3 border-black">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <div className="text-4xl font-black uppercase tracking-tighter mb-2">Ready to build?</div>
            <div className="text-gray-400 font-medium">Your custom typeface is one upload away.</div>
          </div>
          <button onClick={handleStart} className="brutal-btn-outline text-base whitespace-nowrap">
            Get Started Free <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-4 border-black px-8 py-6 flex items-center justify-between text-sm font-mono">
        <span className="font-black uppercase tracking-widest">SVG Font Maker</span>
        <span className="text-gray-500">Built with fonttools + React</span>
      </footer>
    </div>
  );
}
