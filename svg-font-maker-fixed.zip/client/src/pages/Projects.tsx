import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Plus, Type, Pencil, Trash2, ArrowRight, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Projects() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: "", author: "", description: "" });

  const utils = trpc.useUtils();
  const { data: projects, isLoading } = trpc.fontProject.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createMutation = trpc.fontProject.create.useMutation({
    onSuccess: (data) => {
      utils.fontProject.list.invalidate();
      setShowCreate(false);
      setForm({ name: "", author: "", description: "" });
      navigate(`/editor/${data.id}`);
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.fontProject.delete.useMutation({
    onSuccess: () => utils.fontProject.list.invalidate(),
    onError: (err) => toast.error(err.message),
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6 p-8">
        <div className="text-4xl font-black uppercase tracking-tighter">Sign in required</div>
        <button onClick={() => (window.location.href = getLoginUrl())} className="brutal-btn">
          Sign In <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-black">
      {/* Nav */}
      <nav className="border-b-4 border-black px-8 py-4 flex items-center justify-between">
        <button onClick={() => navigate("/")} className="flex items-center gap-3">
          <div className="w-8 h-8 bg-black flex items-center justify-center">
            <Type className="w-5 h-5 text-white" />
          </div>
          <span className="font-black text-xl tracking-tight uppercase">SVG Font Maker</span>
        </button>
        <div className="flex items-center gap-4">
          <span className="font-mono text-sm text-gray-500">{user?.name}</span>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* Header */}
        <div className="flex items-end gap-6 mb-12">
          <div>
            <div className="brutal-tag mb-3">Font Projects</div>
            <h1 className="text-6xl font-black uppercase tracking-tighter leading-none">My Fonts</h1>
          </div>
          <div className="h-1 flex-1 bg-black mb-3 hidden md:block" />
          <button onClick={() => setShowCreate(true)} className="brutal-btn mb-3">
            <Plus className="w-5 h-5" /> New Project
          </button>
        </div>

        {/* Create form */}
        {showCreate && (
          <div className="mb-10 border-5 border-black brutal-shadow-lg p-8 bg-white">
            <div className="font-black text-2xl uppercase tracking-tight mb-6 border-b-3 border-black pb-4">
              New Font Project
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block font-black text-xs uppercase tracking-widest mb-2">Font Name *</label>
                <input
                  className="brutal-input"
                  placeholder="e.g. MyCustomFont"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block font-black text-xs uppercase tracking-widest mb-2">Author</label>
                <input
                  className="brutal-input"
                  placeholder="e.g. Your Name"
                  value={form.author}
                  onChange={(e) => setForm({ ...form, author: e.target.value })}
                />
              </div>
            </div>
            <div className="mb-6">
              <label className="block font-black text-xs uppercase tracking-widest mb-2">Description</label>
              <textarea
                className="brutal-input resize-none"
                rows={2}
                placeholder="Optional description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div className="flex gap-4">
              <button
                onClick={() => createMutation.mutate(form)}
                disabled={!form.name || createMutation.isPending}
                className="brutal-btn"
              >
                {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Create Project
              </button>
              <button onClick={() => setShowCreate(false)} className="brutal-btn-outline">
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Projects grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : !projects || projects.length === 0 ? (
          <div className="border-3 border-black border-dashed p-20 text-center">
            <div className="text-6xl font-black text-gray-200 uppercase tracking-tighter mb-4">Empty</div>
            <p className="text-gray-500 font-medium mb-6">No font projects yet. Create your first one.</p>
            <button onClick={() => setShowCreate(true)} className="brutal-btn">
              <Plus className="w-4 h-4" /> New Project
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-0 border-3 border-black brutal-shadow-lg">
            {projects.map((project, i) => (
              <div
                key={project.id}
                className={`p-6 border-black bg-white hover:bg-gray-50 transition-colors
                  ${i % 3 !== 2 ? "border-r-3" : ""}
                  ${i < projects.length - (projects.length % 3 || 3) ? "border-b-3" : ""}
                `}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-black flex items-center justify-center flex-shrink-0">
                    <Type className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/editor/${project.id}`)}
                      className="brutal-btn-sm bg-black text-white border-black"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm("Delete this project?")) {
                          deleteMutation.mutate({ id: project.id });
                        }
                      }}
                      className="brutal-btn-sm bg-white text-black border-black"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                <div className="font-black text-xl uppercase tracking-tight mb-1 truncate">{project.name}</div>
                {project.author && (
                  <div className="text-sm text-gray-500 font-mono mb-2">by {project.author}</div>
                )}
                {project.description && (
                  <p className="text-sm text-gray-600 line-clamp-2 mb-4">{project.description}</p>
                )}
                <div className="flex items-center justify-between mt-4 pt-4 border-t-2 border-black">
                  <span className="font-mono text-xs text-gray-400">
                    {new Date(project.updatedAt).toLocaleDateString()}
                  </span>
                  <button
                    onClick={() => navigate(`/editor/${project.id}`)}
                    className="flex items-center gap-1 font-black text-xs uppercase tracking-widest hover:underline"
                  >
                    Open <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
