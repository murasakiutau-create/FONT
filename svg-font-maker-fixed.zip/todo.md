# SVG Font Maker - TODO

## Database & Schema
- [x] Create `font_projects` table (id, userId, name, author, description, upm, ascender, descender, createdAt, updatedAt)
- [x] Create `glyphs` table (id, projectId, unicode, char, svgUrl, svgKey, width, createdAt)
- [x] Create `font_files` table (id, projectId, format, fileUrl, fileKey, createdAt)
- [x] Run DB migration

## Backend
- [x] Font project CRUD procedures (create, list, get, update, delete)
- [x] Glyph upload procedure (SVG -> S3, metadata to DB)
- [x] Glyph delete procedure
- [x] Font generation procedure (Python fonttools script invocation)
- [x] Font file download URL procedure
- [x] Python font generation script (SVG -> TTF/OTF via fonttools)
- [x] Fix Python interpreter path (use /usr/bin/python3.11 with PYTHONHOME/PYTHONPATH cleared)

## Frontend - Pages & Layout
- [x] Global brutalist theme (index.css - black/white, heavy typography)
- [x] App.tsx routing setup
- [x] Home/Landing page (brutalist hero, CTA)
- [x] Font Project List page
- [x] Font Editor page (main workspace)
  - [x] Glyph upload grid (A-Z, a-z, 0-9, symbols)
  - [x] SVG file upload per character slot
  - [x] Uploaded glyph preview in slot
  - [x] Delete/re-upload per slot
  - [x] Font metadata form (name, author, UPM, ascender, descender)
  - [x] Generate TTF button
  - [x] Generate OTF button
  - [x] Download generated font files
- [x] Font Preview panel
  - [x] Text input for preview
  - [x] Font size slider
  - [x] Live preview with generated font (CSS @font-face)
- [x] Font History / saved fonts list

## Testing
- [x] Vitest: font project CRUD
- [x] Vitest: glyph upload/delete
- [x] Vitest: font generation procedure

## Deployment
- [x] Checkpoint saved

## Bug Fixes
- [x] Fix TTF cubic Bezier error: auto-convert cubic to quadratic curves using cu2qu before setupGlyf

## Glyphr Studio-like Glyph Editor
- [x] Glyph editor page with full-canvas SVG path editor (GlyphEditorPage.tsx + GlyphCanvas.tsx)
- [x] Typography guidelines: baseline, ascender, descender, x-height, cap-height lines
- [x] Ghost/silhouette overlay: SVG image shown in light gray behind glyph
- [x] Node (anchor point) editing: drag control points on SVG paths
- [x] Bezier handle display and editing (cubic + quadratic)
- [x] Advance width adjustment with visual indicator (drag green AW bar or input)
- [x] Left panel: character list navigation (all glyphs in project)
- [x] Previous/Next glyph navigation buttons
- [x] Zoom in/out and pan on canvas (scroll + alt+drag)
- [x] SVG path data save/update API (backend)
- [x] DB schema: add pathData column to glyphs table
- [x] Re-route /editor/:id to GlyphEditorPage
- [ ] Keyboard shortcuts: arrow keys for nudge, delete for node removal (backlog)

## Known Gaps / Future Improvements
- [x] True reference-font silhouette overlay (render system font glyph in light gray on canvas)
- [x] Unsaved-changes guard when switching glyphs (prompt to save before leaving)
- [x] Support for SVG arc (A) and smooth bezier (S/T) commands in path parser
- [ ] Autosave option for node edits (backlog)

## Glyph Transform Features
- [x] Drag entire SVG glyph to move (translate) on canvas
- [x] Bounding box handles: drag corners/edges to scale glyph
- [x] Numeric input in right panel: X position, Y position, Width, Height
- [x] Aspect ratio lock toggle (proportional scaling)
- [x] Reset transform button

## Bug Fixes (Round 2)
- [x] Fix "Failed to fetch" TRPCClientError on /editor/2 page (upgraded to connection pool with keepAlive)
- [x] Add client-side retry/error UI for editor bootstrap queries (project/glyph/listFiles) with explicit error messaging

## Bug Fixes (Round 3)
- [x] Fix glyph horizontal centering: when SVG is scaled to fit guidelines, glyph appears left-aligned instead of centered horizontally within advance width
- [x] Reset Transform button now clears saved pathData (sets to null in DB) so SVG is re-normalized with correct centering
- [x] updateGlyphPathData: empty string treated as null (reset to original SVG)

## Bug Fixes (Round 4)
- [x] Fix reference silhouette (gray system font character) horizontal position: centered within advance width using measureText

## Bug Fixes (Round 5)
- [x] Fix TTF generation error: "Glyph has cubic Bezier outlines but glyphDataFormat=0" - added robust cu2qu fallback chain (cu2qu.pens -> fontTools.cu2qu.pens -> direct) in both parse_svg_to_glyph_from_path_data and parse_svg_to_glyph_from_file

## Bug Fixes (Round 6)
- [x] Fix glyph advance width mismatch: in font preview, 'a' appears small with large right-side space
  - GlyphCanvas: SVG normalization now scales by height only (scaleY), auto-computes advanceWidth from actual glyph width + side bearings, calls onWidthChange() to update
  - generate_font.py: added compute_path_bbox() to auto-correct advanceWidth from pathData extents when stored value differs by >50 units
  - Reset Transform button now also clears pendingWidth so advanceWidth is recalculated from scratch

## Bug Fixes (Round 7)
- [x] Fix persistent right-side space in font preview: root cause was large left bearing (xMin=157) in pathData coordinates. Added _shift_path_x() to normalize xMin=sideBearing(20) and set advanceWidth=glyphW+2*sideBearing, so left/right bearings are now equal and minimal

## Feature: Hiragana & Katakana Support
- [x] Add hiragana glyph slots (U+3041-U+3096) to font editor glyph grid (left panel)
- [x] Add katakana glyph slots (U+30A1-U+30F6) to font editor glyph grid (left panel)
- [x] Show gray reference silhouette for hiragana/katakana: font stack updated to include Hiragino Sans, Yu Gothic, Noto Sans JP
- [x] Font generation (generate_font.py) handles hiragana/katakana Unicode codepoints correctly (uni3042, uni30A2 etc.)
- [x] OS/2 ulUnicodeRange2 bits set for hiragana (bit49) and katakana (bit50) when present
- [x] Array.from() used instead of split('') to correctly handle multi-byte codepoints
- [x] String.fromCodePoint() used instead of String.fromCharCode() for correct Unicode handling

## Bug Fixes (Round 8)
- [x] Fix multi-path SVG import: changed regex from single match to Array.from(matchAll()) to collect ALL path d attributes and join them into one compound path string; backend (fontTools SVGPath) already handles multi-path correctly

## Bug Fixes (Round 9)
- [x] Fix multi-path SVG split: changed normalization from viewBox-based to actual path bounding box; all paths now share the same coordinate origin (minX,minY) so relative positions are preserved correctly

## Bug Fixes (Round 10)
- [x] Fix generate_font.py line 358: verified ty = ascender + y_min * scale is CORRECT (maps svg_y=y_min to font_y=ascender for all viewBox origins)

## Bug Fixes (Round 11) - GlyphCanvas.tsx audit
- [x] Bug 1: SVG import useEffect has `advanceWidth` in deps → triggers re-normalization loop when onWidthChange fires (advanceWidth changes → re-import → onWidthChange → advanceWidth changes...)
- [ ] Bug 2: computeBBox uses control points only, not true bezier extrema → bbox slightly wrong for curved paths (deferred - minor visual impact)
- [x] Bug 3: Reference silhouette font size uses `ascender * scale` but should use `fontH * scale` (full cap height) for correct proportional sizing
- [ ] Bug 4: Ghost SVG image drawn at (0, ascender) with width=advanceWidth but path bbox normalization uses sideBearing offset → ghost misaligned with actual glyph (deferred - low priority)
- [x] Bug 5: `c` (relative cubic) command: x2/y2 computed as `cx+num()` AFTER cx has already been updated by `x=cx+num()` → wrong control point coordinates
- [x] Bug 6: `s`/`S` smooth cubic: x2/y2 read BEFORE updating cx/cy but x/y read after → inconsistent relative base (fixed with ox/oy snapshot)
- [x] Bug 7: pathData empty string treated as falsy → falls through to SVG re-import instead of showing empty glyph (fixed: pathData != null check)

## Bug Fixes (Round 12) - SVG <g> transform support
- [x] GlyphCanvas.tsx: SVG path extraction ignores parent <g> transform attributes → paths appear at wrong position/scale when SVG uses <g transform="...">
- [x] generate_font.py: verify fontTools SVGPath handles <g> transform correctly (fontTools should handle this natively, but confirm)

## Bug Fixes & Features (Round 13)
- [x] Fix: preview not updating after font generation (FontFace API + fontFamilyKey timestamp)
- [x] Fix: REPLACE SVG sometimes not overwriting (race condition or pendingPath not cleared)
- [x] Feature: editor zoom slider (+ / - slider to adjust canvas zoom level)
- [x] Feature: path cleanup (remove duplicate points, degenerate segments) - per-glyph in ATTRIBUTES + bulk
- [x] Feature: path simplification / point decimation (reduce nodes, repeatable/staged) - per-glyph in ATTRIBUTES + bulk
- [x] Feature: curve smoothing (smooth bezier handles) - per-glyph in ATTRIBUTES + bulk

## Bug Fixes (Round 14)
- [x] Fix: ATTRIBUTES panel X/Y/W/H numeric inputs reset to 0 when user clears the field (parseInt(e.target.value) || 0 was the culprit)
- [x] Fix: window.confirm popup when switching glyphs removed (silent discard)
