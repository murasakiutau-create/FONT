#!/usr/bin/env python3
"""
Font generation script: SVG glyphs -> TTF/OTF
Usage: python3 generate_font.py <config_json_path> <output_path> <format>
  format: ttf or otf
"""

import sys
import json
import os
import re
import tempfile
import urllib.request

from fontTools.fontBuilder import FontBuilder
from fontTools.pens.t2CharStringPen import T2CharStringPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import SVGPath
from fontTools.pens.recordingPen import RecordingPen


def download_svg(url: str, dest: str):
    urllib.request.urlretrieve(url, dest)


# ---- SVG transform matrix helpers ----
# Matrix format: [a, b, c, d, e, f]  (same as SVG/CSS matrix)
# Point transform: x' = a*x + c*y + e,  y' = b*x + d*y + f

import math as _math

def _parse_svg_transform(transform_str):
    """Parse SVG transform attribute into a 2D affine matrix [a,b,c,d,e,f]."""
    result = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]

    def mat_mul(m1, m2):
        a1,b1,c1,d1,e1,f1 = m1
        a2,b2,c2,d2,e2,f2 = m2
        return [
            a1*a2 + c1*b2, b1*a2 + d1*b2,
            a1*c2 + c1*d2, b1*c2 + d1*d2,
            a1*e2 + c1*f2 + e1, b1*e2 + d1*f2 + f1,
        ]

    for m in re.finditer(r'(\w+)\s*\(([^)]*)\)', transform_str):
        func = m.group(1)
        args = [float(x) for x in re.split(r'[\s,]+', m.group(2).strip()) if x]
        if func == 'matrix':
            mat = args
        elif func == 'translate':
            tx = args[0] if args else 0.0
            ty = args[1] if len(args) > 1 else 0.0
            mat = [1, 0, 0, 1, tx, ty]
        elif func == 'scale':
            sx = args[0] if args else 1.0
            sy = args[1] if len(args) > 1 else sx
            mat = [sx, 0, 0, sy, 0, 0]
        elif func == 'rotate':
            angle = _math.radians(args[0] if args else 0.0)
            cos_a, sin_a = _math.cos(angle), _math.sin(angle)
            if len(args) == 3:
                cx, cy = args[1], args[2]
                mat = [cos_a, sin_a, -sin_a, cos_a,
                       cx - cx*cos_a + cy*sin_a, cy - cx*sin_a - cy*cos_a]
            else:
                mat = [cos_a, sin_a, -sin_a, cos_a, 0, 0]
        elif func == 'skewX':
            mat = [1, 0, _math.tan(_math.radians(args[0] if args else 0)), 1, 0, 0]
        elif func == 'skewY':
            mat = [1, _math.tan(_math.radians(args[0] if args else 0)), 0, 1, 0, 0]
        else:
            continue
        result = mat_mul(result, mat)
    return result


def _apply_matrix_to_svg_paths(svg_path):
    """Pre-process SVG file: flatten all <g> transforms into <path> d attributes.
    Returns a modified SVG XML string with all transforms resolved.
    This works around fontTools SVGPath not supporting <g transform>.
    """
    import xml.etree.ElementTree as ET
    import copy

    tree = ET.parse(svg_path)
    root = tree.getroot()

    # Strip XML namespace for easier tag matching
    def strip_ns(tag):
        return tag.split('}', 1)[1] if '}' in tag else tag

    def get_accumulated_transform(el):
        """Walk up the tree collecting transforms (outermost first)."""
        chain = []
        node = el
        while node is not None:
            t = node.get('transform')
            if t:
                chain.insert(0, _parse_svg_transform(t))
            node = node  # will be replaced by parent below
            # ElementTree doesn't have parent refs, so we use a parent_map
            break  # handled by parent_map below
        return chain

    # Build parent map
    parent_map = {child: parent for parent in root.iter() for child in parent}

    def collect_transform(el):
        """Accumulate all ancestor transforms for an element."""
        chain = []
        node = el
        while node is not None:
            t = node.get('transform')
            if t:
                chain.insert(0, _parse_svg_transform(t))
            node = parent_map.get(node)
        # Compose: chain[0] is outermost, chain[-1] is innermost
        mat = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]
        for m in chain:
            a1,b1,c1,d1,e1,f1 = mat
            a2,b2,c2,d2,e2,f2 = m
            mat = [
                a1*a2 + c1*b2, b1*a2 + d1*b2,
                a1*c2 + c1*d2, b1*c2 + d1*d2,
                a1*e2 + c1*f2 + e1, b1*e2 + d1*f2 + f1,
            ]
        return mat

    def is_identity(mat):
        return (mat[0]==1 and mat[1]==0 and mat[2]==0 and
                mat[3]==1 and mat[4]==0 and mat[5]==0)

    def apply_mat_to_path_d(d, mat):
        """Apply affine matrix to all coordinates in a path d string."""
        a, b, c, dd, e, f = mat
        tokens = re.sub(r'([MmLlCcQqZzHhVvSsTtAa])', r' \1 ', d).strip().split()
        result = []
        i = 0
        last_cmd = ''
        cx, cy = 0.0, 0.0

        def pt(x, y):
            return a*x + c*y + e, b*x + dd*y + f

        def num():
            nonlocal i
            v = float(tokens[i]); i += 1; return v

        while i < len(tokens):
            t = tokens[i]
            if re.match(r'[a-zA-Z]', t):
                last_cmd = t
                result.append(t)
                i += 1
                continue
            try:
                if last_cmd in ('M', 'L'):
                    x, y = num(), num()
                    nx, ny = pt(x, y)
                    cx, cy = nx, ny
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                elif last_cmd in ('m', 'l'):
                    dx, dy = num(), num()
                    # Relative: only apply the linear part (no translation)
                    nx = a*dx + c*dy
                    ny = b*dx + dd*dy
                    cx += nx; cy += ny
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                elif last_cmd == 'H':
                    x = num()
                    nx, ny = pt(x, cy)
                    # Convert to L since H doesn't work after rotation/skew
                    result[-1] = 'L'  # replace 'H' with 'L'
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                    cx = nx; cy = ny
                elif last_cmd == 'h':
                    dx = num()
                    nx = a*dx; ny = b*dx
                    result[-1] = 'l'
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                    cx += nx; cy += ny
                elif last_cmd == 'V':
                    y = num()
                    nx, ny = pt(cx, y)
                    result[-1] = 'L'
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                    cx = nx; cy = ny
                elif last_cmd == 'v':
                    dy = num()
                    nx = c*dy; ny = dd*dy
                    result[-1] = 'l'
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                    cx += nx; cy += ny
                elif last_cmd == 'C':
                    pairs = []
                    for _ in range(3):
                        x, y = num(), num()
                        nx, ny = pt(x, y)
                        pairs += [f'{nx:.6g}', f'{ny:.6g}']
                    result += pairs
                    cx, cy = float(pairs[-2]), float(pairs[-1])
                elif last_cmd == 'c':
                    pairs = []
                    for _ in range(3):
                        dx, dy = num(), num()
                        nx = a*dx + c*dy; ny = b*dx + dd*dy
                        pairs += [f'{nx:.6g}', f'{ny:.6g}']
                    result += pairs
                    cx += float(pairs[-2]); cy += float(pairs[-1])
                elif last_cmd in ('S', 'Q'):
                    pairs = []
                    for _ in range(2):
                        x, y = num(), num()
                        nx, ny = pt(x, y)
                        pairs += [f'{nx:.6g}', f'{ny:.6g}']
                    result += pairs
                    cx, cy = float(pairs[-2]), float(pairs[-1])
                elif last_cmd in ('s', 'q'):
                    pairs = []
                    for _ in range(2):
                        dx, dy = num(), num()
                        nx = a*dx + c*dy; ny = b*dx + dd*dy
                        pairs += [f'{nx:.6g}', f'{ny:.6g}']
                    result += pairs
                    cx += float(pairs[-2]); cy += float(pairs[-1])
                elif last_cmd in ('T', 't'):
                    if last_cmd == 'T':
                        x, y = num(), num()
                        nx, ny = pt(x, y)
                    else:
                        dx, dy = num(), num()
                        nx = a*dx + c*dy; ny = b*dx + dd*dy
                    result += [f'{nx:.6g}', f'{ny:.6g}']
                    if last_cmd == 'T': cx, cy = nx, ny
                    else: cx += nx; cy += ny
                elif last_cmd in ('A', 'a'):
                    # Arc: skip rx,ry,x-rotation,large-arc,sweep; transform endpoint
                    rx, ry, xrot = num(), num(), num()
                    large_arc, sweep = num(), num()
                    if last_cmd == 'A':
                        x, y = num(), num()
                        nx, ny = pt(x, y)
                        cx, cy = nx, ny
                    else:
                        dx, dy = num(), num()
                        nx = a*dx + c*dy; ny = b*dx + dd*dy
                        cx += nx; cy += ny
                    result += [f'{rx:.6g}', f'{ry:.6g}', f'{xrot:.6g}',
                               f'{int(large_arc)}', f'{int(sweep)}',
                               f'{nx:.6g}', f'{ny:.6g}']
                elif last_cmd in ('Z', 'z'):
                    i += 1
                else:
                    result.append(tokens[i]); i += 1
            except (IndexError, ValueError):
                break
        return ' '.join(result)

    # Process all <path> elements: apply accumulated ancestor transforms
    modified = False
    for el in root.iter():
        if strip_ns(el.tag) == 'path' and el.get('d'):
            mat = collect_transform(el)
            if not is_identity(mat):
                new_d = apply_mat_to_path_d(el.get('d'), mat)
                el.set('d', new_d)
                # Remove transform from this element (already baked in)
                if el.get('transform'):
                    del el.attrib['transform']
                modified = True

    # Remove transform from all <g> elements (already applied to paths)
    for el in root.iter():
        if strip_ns(el.tag) == 'g' and el.get('transform'):
            del el.attrib['transform']

    if not modified:
        return None  # No transforms found, use original file

    # Write modified SVG to a temp file
    import io
    buf = io.BytesIO()
    tree.write(buf, xml_declaration=True, encoding='utf-8')
    return buf.getvalue().decode('utf-8')


# ---- Simple SVG path parser for font-space pathData ----
def _tokenize(d):
    tokens = re.sub(r'([MmLlCcQqZzHhVvSsTtAa])', r' \1 ', d).strip().split()
    return tokens


def draw_path_data_to_pen(path_data: str, pen):
    """Draw a font-coordinate path string directly onto a pen."""
    tokens = _tokenize(path_data)
    i = 0
    last_cmd = ''
    cx, cy = 0.0, 0.0
    last_ctrl_x, last_ctrl_y = 0.0, 0.0
    last_was_cubic = False
    last_was_quad = False
    # Track whether a subpath is currently open (moveTo called but not yet closed)
    subpath_open = False

    def num():
        nonlocal i
        v = float(tokens[i])
        i += 1
        return v

    while i < len(tokens):
        t = tokens[i]
        if re.match(r'[a-zA-Z]', t):
            last_cmd = t
            i += 1

        prev_was_cubic = last_was_cubic
        prev_was_quad = last_was_quad
        last_was_cubic = False
        last_was_quad = False

        try:
            if last_cmd == 'M':
                # Close any open subpath before starting a new one
                if subpath_open:
                    pen.endPath()
                    subpath_open = False
                x, y = num(), num()
                cx, cy = x, y
                pen.moveTo((x, y))
                subpath_open = True
                last_cmd = 'L'
            elif last_cmd == 'm':
                # Close any open subpath before starting a new one
                if subpath_open:
                    pen.endPath()
                    subpath_open = False
                x, y = cx + num(), cy + num()
                cx, cy = x, y
                pen.moveTo((x, y))
                subpath_open = True
                last_cmd = 'l'
            elif last_cmd == 'L':
                x, y = num(), num()
                cx, cy = x, y
                pen.lineTo((x, y))
            elif last_cmd == 'l':
                x, y = cx + num(), cy + num()
                cx, cy = x, y
                pen.lineTo((x, y))
            elif last_cmd == 'H':
                x = num()
                cx = x
                pen.lineTo((x, cy))
            elif last_cmd == 'h':
                x = cx + num()
                cx = x
                pen.lineTo((x, cy))
            elif last_cmd == 'V':
                y = num()
                cy = y
                pen.lineTo((cx, y))
            elif last_cmd == 'v':
                y = cy + num()
                cy = y
                pen.lineTo((cx, y))
            elif last_cmd == 'C':
                x1, y1, x2, y2, x, y = num(), num(), num(), num(), num(), num()
                last_ctrl_x, last_ctrl_y = x2, y2
                cx, cy = x, y
                last_was_cubic = True
                pen.curveTo((x1, y1), (x2, y2), (x, y))
            elif last_cmd == 'c':
                x1, y1 = cx + num(), cy + num()
                x2, y2 = cx + num(), cy + num()
                x, y = cx + num(), cy + num()
                last_ctrl_x, last_ctrl_y = x2, y2
                cx, cy = x, y
                last_was_cubic = True
                pen.curveTo((x1, y1), (x2, y2), (x, y))
            elif last_cmd == 'S':
                x1 = 2 * cx - last_ctrl_x if prev_was_cubic else cx
                y1 = 2 * cy - last_ctrl_y if prev_was_cubic else cy
                x2, y2, x, y = num(), num(), num(), num()
                last_ctrl_x, last_ctrl_y = x2, y2
                cx, cy = x, y
                last_was_cubic = True
                pen.curveTo((x1, y1), (x2, y2), (x, y))
            elif last_cmd == 's':
                x1 = 2 * cx - last_ctrl_x if prev_was_cubic else cx
                y1 = 2 * cy - last_ctrl_y if prev_was_cubic else cy
                x2, y2 = cx + num(), cy + num()
                x, y = cx + num(), cy + num()
                last_ctrl_x, last_ctrl_y = x2, y2
                cx, cy = x, y
                last_was_cubic = True
                pen.curveTo((x1, y1), (x2, y2), (x, y))
            elif last_cmd == 'Q':
                x1, y1, x, y = num(), num(), num(), num()
                last_ctrl_x, last_ctrl_y = x1, y1
                cx, cy = x, y
                last_was_quad = True
                pen.qCurveTo((x1, y1), (x, y))
            elif last_cmd == 'q':
                x1, y1 = cx + num(), cy + num()
                x, y = cx + num(), cy + num()
                last_ctrl_x, last_ctrl_y = x1, y1
                cx, cy = x, y
                last_was_quad = True
                pen.qCurveTo((x1, y1), (x, y))
            elif last_cmd == 'T':
                x1 = 2 * cx - last_ctrl_x if prev_was_quad else cx
                y1 = 2 * cy - last_ctrl_y if prev_was_quad else cy
                x, y = num(), num()
                cx, cy = x, y
                last_was_quad = True
                pen.qCurveTo((x1, y1), (x, y))
            elif last_cmd == 't':
                x1 = 2 * cx - last_ctrl_x if prev_was_quad else cx
                y1 = 2 * cy - last_ctrl_y if prev_was_quad else cy
                x, y = cx + num(), cy + num()
                cx, cy = x, y
                last_was_quad = True
                pen.qCurveTo((x1, y1), (x, y))
            elif last_cmd in ('A', 'a'):
                rel = last_cmd == 'a'
                num(); num(); num(); num(); num()
                x = cx + num() if rel else num()
                y = cy + num() if rel else num()
                cx, cy = x, y
                pen.lineTo((x, y))
            elif last_cmd in ('Z', 'z'):
                pen.endPath()
                subpath_open = False
            else:
                i += 1
        except (IndexError, ValueError):
            break

        if not last_was_cubic and not last_was_quad:
            last_ctrl_x, last_ctrl_y = cx, cy

    # Close any remaining open subpath that was not explicitly closed with Z
    if subpath_open:
        pen.endPath()


def compute_path_bbox(path_data: str):
    """Compute bounding box of a font-space path string. Returns (minX, minY, maxX, maxY) or None."""
    tokens = _tokenize(path_data)
    xs, ys = [], []
    i = 0
    cx, cy = 0.0, 0.0
    last_cmd = ''
    while i < len(tokens):
        t = tokens[i]
        if re.match(r'[a-zA-Z]', t):
            last_cmd = t
            i += 1
            continue
        try:
            def num():
                nonlocal i
                v = float(tokens[i]); i += 1; return v
            if last_cmd in ('M', 'L'):
                x, y = num(), num(); xs.append(x); ys.append(y); cx, cy = x, y
            elif last_cmd in ('m', 'l'):
                x, y = cx + num(), cy + num(); xs.append(x); ys.append(y); cx, cy = x, y
            elif last_cmd == 'H':
                x = num(); xs.append(x); cx = x
            elif last_cmd == 'h':
                x = cx + num(); xs.append(x); cx = x
            elif last_cmd == 'V':
                y = num(); ys.append(y); cy = y
            elif last_cmd == 'v':
                y = cy + num(); ys.append(y); cy = y
            elif last_cmd in ('C', 'S'):
                for _ in range(3):
                    x, y = num(), num(); xs.append(x); ys.append(y)
                cx, cy = xs[-1], ys[-1]
            elif last_cmd in ('c', 's'):
                for _ in range(3):
                    x, y = cx + num(), cy + num(); xs.append(x); ys.append(y)
                cx, cy = xs[-1], ys[-1]
            elif last_cmd in ('Q', 'T'):
                for _ in range(2):
                    x, y = num(), num(); xs.append(x); ys.append(y)
                cx, cy = xs[-1], ys[-1]
            elif last_cmd in ('q', 't'):
                for _ in range(2):
                    x, y = cx + num(), cy + num(); xs.append(x); ys.append(y)
                cx, cy = xs[-1], ys[-1]
            elif last_cmd in ('Z', 'z'):
                pass
            else:
                i += 1
        except (IndexError, ValueError):
            break
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def _shift_path_x(path_data: str, dx: float) -> str:
    """Shift all absolute X coordinates in a path string by dx.
    Handles M, L, C, Q, H commands (absolute only, as GlyphCanvas emits absolute paths).
    """
    tokens = _tokenize(path_data)
    result = []
    i = 0
    last_cmd = ''
    while i < len(tokens):
        t = tokens[i]
        if re.match(r'[a-zA-Z]', t):
            last_cmd = t
            result.append(t)
            i += 1
            continue
        try:
            if last_cmd in ('M', 'L'):
                x, y = float(tokens[i]), float(tokens[i+1])
                result.append(f'{x + dx:.6g}'); result.append(f'{y:.6g}')
                i += 2
            elif last_cmd == 'C':
                # 3 pairs: x1,y1 x2,y2 x,y
                for _ in range(3):
                    x, y = float(tokens[i]), float(tokens[i+1])
                    result.append(f'{x + dx:.6g}'); result.append(f'{y:.6g}')
                    i += 2
            elif last_cmd == 'Q':
                # 2 pairs: x1,y1 x,y
                for _ in range(2):
                    x, y = float(tokens[i]), float(tokens[i+1])
                    result.append(f'{x + dx:.6g}'); result.append(f'{y:.6g}')
                    i += 2
            elif last_cmd == 'H':
                x = float(tokens[i])
                result.append(f'{x + dx:.6g}')
                i += 1
            elif last_cmd in ('Z', 'z'):
                i += 1
            else:
                result.append(tokens[i])
                i += 1
        except (IndexError, ValueError):
            result.append(tokens[i])
            i += 1
    return ' '.join(result)


def parse_svg_to_glyph_from_path_data(path_data: str, advance_width: int, pen_type: str,
                                       lsb: int | None = None, rsb: int | None = None):
    """Use pre-computed font-space path data directly.
    advance_width is used as a fallback; actual width is computed from path bbox.
    lsb/rsb override the auto-computed side bearings when provided.
    """
    # Auto-compute advance width and normalize left bearing.
    # The path is in font-space coordinates. We shift the glyph so that
    # xMin = lsb (left side bearing), eliminating excess left space.
    bbox = compute_path_bbox(path_data)
    shift_x = 0.0
    if bbox is not None:
        min_x, _, max_x, _ = bbox
        glyph_w = max_x - min_x
        # Use explicit lsb/rsb if provided, otherwise auto-compute (5% of width, min 20)
        if lsb is not None:
            left_bearing = lsb
        else:
            left_bearing = max(20, round(glyph_w * 0.05))
        if rsb is not None:
            right_bearing = rsb
        else:
            right_bearing = max(20, round(glyph_w * 0.05))
        # Shift glyph so that xMin becomes left_bearing
        shift_x = left_bearing - min_x
        # advanceWidth = lsb + glyph_width + rsb
        advance_width = round(left_bearing + glyph_w + right_bearing)

    # Apply horizontal shift to normalize left bearing
    if shift_x != 0.0:
        path_data = _shift_path_x(path_data, shift_x)

    if pen_type == "otf":
        pen = T2CharStringPen(advance_width, None)
        draw_path_data_to_pen(path_data, pen)
        return pen.getCharString(), advance_width
    else:
        # TTF: need quadratic curves
        # Record first, then convert cubic->quadratic via cu2qu
        rec_pen = RecordingPen()
        draw_path_data_to_pen(path_data, rec_pen)
        tt_pen = TTGlyphPen(None)
        converted = False
        try:
            from cu2qu.pens import Cu2QuPen
            cu2qu_pen = Cu2QuPen(tt_pen, max_err=1.0, reverse_direction=False)
            rec_pen.replay(cu2qu_pen)
            converted = True
        except (ImportError, Exception):
            pass
        if not converted:
            # Fallback: use fontTools built-in cu2qu if available
            try:
                from fontTools.cu2qu.pens import Cu2QuPen as FTCu2QuPen
                tt_pen2 = TTGlyphPen(None)
                cu2qu_pen2 = FTCu2QuPen(tt_pen2, max_err=1.0, reverse_direction=False)
                rec_pen.replay(cu2qu_pen2)
                return tt_pen2.glyph(), advance_width
            except Exception as e2:
                raise RuntimeError(
                    f"cu2qu conversion failed for TTF glyph. "
                    f"Install cu2qu: pip install cu2qu. Details: {e2}"
                ) from e2
        return tt_pen.glyph(), advance_width


def parse_svg_to_glyph_from_file(svg_path: str, upm: int, ascender: int, pen_type: str,
                                   lsb: int | None = None, rsb: int | None = None):
    """Parse SVG file and draw onto a pen. Returns (glyph_or_charstring, advance_width).
    lsb/rsb override the auto-computed side bearings when provided.
    """
    import xml.etree.ElementTree as ET
    import tempfile as _tempfile

    # Pre-process SVG: flatten <g> transforms into path d attributes
    # (fontTools SVGPath does not support <g transform>)
    modified_svg = _apply_matrix_to_svg_paths(svg_path)
    if modified_svg is not None:
        # Write modified SVG to a temp file and use that instead
        _tmp = _tempfile.NamedTemporaryFile(suffix='.svg', mode='w',
                                            delete=False, encoding='utf-8')
        _tmp.write(modified_svg)
        _tmp.close()
        actual_svg_path = _tmp.name
    else:
        actual_svg_path = svg_path

    try:
        tree = ET.parse(actual_svg_path)
        root = tree.getroot()

        vb = root.get("viewBox") or root.get("viewbox")
        if vb:
            parts = vb.replace(",", " ").split()
            x_min, y_min, vb_width, vb_height = (float(p) for p in parts)
        else:
            w_attr = root.get("width", "1000")
            h_attr = root.get("height", "1000")
            x_min, y_min = 0.0, 0.0
            vb_width = float(re.sub(r'[^0-9.]', '', w_attr) or "1000")
            vb_height = float(re.sub(r'[^0-9.]', '', h_attr) or "1000")

        if vb_height == 0:
            vb_height = 1000.0
        if vb_width == 0:
            vb_width = 600.0

        scale = upm / vb_height
        # Compute advance width with side bearings
        # glyph_width = vb_width * scale; advance = lsb + glyph_width + rsb
        raw_glyph_w = vb_width * scale
        if lsb is not None and rsb is not None:
            advance_width = max(int(lsb + raw_glyph_w + rsb), 100)
            # Shift glyph right by lsb so xMin aligns to lsb
            tx = -x_min * scale + lsb
        else:
            advance_width = max(int(raw_glyph_w), 100)
            tx = -x_min * scale
        ty = ascender + y_min * scale
        transform = (scale, 0, 0, -scale, tx, ty)

        # Step 1: Record all SVG path operations (may contain cubic Bezier curves)
        rec_pen = RecordingPen()
        t_pen = TransformPen(rec_pen, transform)
        svg_obj = SVGPath(actual_svg_path)
        svg_obj.draw(t_pen)

        if pen_type == "otf":
            raw_pen = T2CharStringPen(advance_width, None)
            rec_pen.replay(raw_pen)
            glyph = raw_pen.getCharString()
        else:
            # TTF: convert cubic -> quadratic via cu2qu
            raw_pen = TTGlyphPen(None)
            converted = False
            try:
                from cu2qu.pens import Cu2QuPen
                cu2qu_pen = Cu2QuPen(raw_pen, max_err=1.0, reverse_direction=False)
                rec_pen.replay(cu2qu_pen)
                converted = True
            except (ImportError, Exception):
                pass
            if not converted:
                try:
                    from fontTools.cu2qu.pens import Cu2QuPen as FTCu2QuPen
                    raw_pen2 = TTGlyphPen(None)
                    cu2qu_pen2 = FTCu2QuPen(raw_pen2, max_err=1.0, reverse_direction=False)
                    rec_pen.replay(cu2qu_pen2)
                    glyph = raw_pen2.glyph()
                except Exception as e2:
                    raise RuntimeError(
                        f"cu2qu conversion failed for TTF glyph from SVG file. "
                        f"Install cu2qu: pip install cu2qu. Details: {e2}"
                    ) from e2
            else:
                glyph = raw_pen.glyph()
    finally:
        if modified_svg is not None and actual_svg_path != svg_path:
            try:
                os.unlink(actual_svg_path)
            except OSError:
                pass

    return glyph, advance_width


def build_font(config: dict, output_path: str, fmt: str):
    upm = config.get("upm", 1000)
    ascender = config.get("ascender", 800)
    descender = config.get("descender", -200)
    font_name = config.get("name", "CustomFont")
    author = config.get("author", "Unknown")
    glyphs_data = config.get("glyphs", [])

    pen_type = "otf" if fmt == "otf" else "ttf"

    fb = FontBuilder(upm, isTTF=(pen_type == "ttf"))

    glyph_order = [".notdef"]
    metrics = {}
    glyph_objects = {}
    char_map = {}

    # Build .notdef glyph
    if pen_type == "ttf":
        notdef_pen = TTGlyphPen(None)
    else:
        notdef_pen = T2CharStringPen(500, None)

    notdef_pen.moveTo((50, descender))
    notdef_pen.lineTo((450, descender))
    notdef_pen.lineTo((450, ascender))
    notdef_pen.lineTo((50, ascender))
    notdef_pen.closePath()
    notdef_pen.moveTo((100, descender + 50))
    notdef_pen.lineTo((100, ascender - 50))
    notdef_pen.lineTo((400, ascender - 50))
    notdef_pen.lineTo((400, descender + 50))
    notdef_pen.closePath()

    if pen_type == "ttf":
        notdef_glyph = notdef_pen.glyph()
    else:
        notdef_glyph = notdef_pen.getCharString()

    glyph_objects[".notdef"] = notdef_glyph
    metrics[".notdef"] = (500, 0)

    # Project-level default side bearings
    default_lsb = config.get("defaultLsb", 50)
    default_rsb = config.get("defaultRsb", 50)

    with tempfile.TemporaryDirectory() as tmpdir:
        for g in glyphs_data:
            unicode_val = g.get("unicode")
            svg_url = g.get("svgUrl")
            path_data = g.get("pathData")  # pre-computed font-space path
            width_hint = g.get("width", 600)
            # Per-glyph side bearings; fall back to project defaults
            glyph_lsb = g.get("lsb") if g.get("lsb") is not None else default_lsb
            glyph_rsb = g.get("rsb") if g.get("rsb") is not None else default_rsb

            if not unicode_val or not svg_url:
                continue

            glyph_name = f"uni{unicode_val:04X}"

            try:
                if path_data:
                    # Use edited font-space path data directly
                    glyph_obj, adv = parse_svg_to_glyph_from_path_data(
                        path_data, width_hint, pen_type,
                        lsb=glyph_lsb, rsb=glyph_rsb
                    )
                else:
                    # Fall back to parsing original SVG file
                    svg_local = os.path.join(tmpdir, f"{glyph_name}.svg")
                    download_svg(svg_url, svg_local)
                    glyph_obj, adv = parse_svg_to_glyph_from_file(
                        svg_local, upm, ascender, pen_type,
                        lsb=glyph_lsb, rsb=glyph_rsb
                    )

                glyph_objects[glyph_name] = glyph_obj
                metrics[glyph_name] = (adv, 0)
                glyph_order.append(glyph_name)
                char_map[unicode_val] = glyph_name
            except Exception as e:
                print(f"Warning: failed to process glyph U+{unicode_val:04X}: {e}", file=sys.stderr)
                continue

    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(char_map)

    if pen_type == "ttf":
        fb.setupGlyf(glyph_objects)
    else:
        ps_name = font_name.replace(" ", "-")
        fb.setupCFF(
            psName=ps_name,
            fontInfo={
                "version": "1.0",
                "FullName": font_name,
                "FamilyName": font_name,
                "Weight": "Regular",
            },
            charStringsDict=glyph_objects,
            privateDict={},
        )

    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=ascender, descent=descender)

    fb.setupNameTable({
        "familyName": font_name,
        "styleName": "Regular",
        "fullName": font_name,
        "psName": font_name.replace(" ", "-"),
        "manufacturer": author,
        "designer": author,
    })

    # Determine Unicode ranges from actual glyphs
    has_hiragana = any(0x3041 <= cp <= 0x309F for cp in char_map)
    has_katakana = any(0x30A0 <= cp <= 0x30FF for cp in char_map)
    # ulUnicodeRange bits: bit49=Hiragana, bit50=Katakana (in ulUnicodeRange2)
    unicode_range1 = 0x00000003  # Basic Latin + Latin-1
    unicode_range2 = 0
    if has_hiragana:
        unicode_range2 |= (1 << (49 - 32))  # bit 49
    if has_katakana:
        unicode_range2 |= (1 << (50 - 32))  # bit 50

    fb.setupOS2(
        sTypoAscender=ascender,
        sTypoDescender=descender,
        sTypoLineGap=0,
        usWinAscent=ascender,
        usWinDescent=abs(descender),
        sxHeight=int(ascender * 0.5),
        sCapHeight=int(ascender * 0.7),
        ulUnicodeRange1=unicode_range1,
        ulUnicodeRange2=unicode_range2,
    )

    fb.setupPost()
    fb.setupHead(unitsPerEm=upm)

    fb.font.save(output_path)
    print(f"Font saved to {output_path}")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: generate_font.py <config.json> <output_path> <ttf|otf>")
        sys.exit(1)

    config_path = sys.argv[1]
    output_path = sys.argv[2]
    fmt = sys.argv[3].lower()

    with open(config_path, "r") as f:
        config = json.load(f)

    build_font(config, output_path, fmt)
