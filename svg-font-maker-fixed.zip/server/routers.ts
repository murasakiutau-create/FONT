import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  createFontProject, getFontProjectsByUser, getFontProjectById,
  updateFontProject, deleteFontProject,
  upsertGlyph, getGlyphsByProject, deleteGlyph, updateGlyphWidth, updateGlyphPathData, getGlyphById,
  saveFontFile, getFontFilesByProject,
  updateGlyphSideBearings, bulkUpdateGlyphSideBearings, updateProjectDefaultSideBearings,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import os from "os";
import path from "path";

const execAsync = promisify(exec);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  fontProject: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getFontProjectsByUser(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.id);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        return project;
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
        author: z.string().max(255).optional(),
        description: z.string().optional(),
        upm: z.number().int().min(100).max(4096).default(1000),
        ascender: z.number().int().default(800),
        descender: z.number().int().default(-200),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await createFontProject({ ...input, userId: ctx.user.id });
        return { id };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        author: z.string().max(255).optional(),
        description: z.string().optional(),
        upm: z.number().int().min(100).max(4096).optional(),
        ascender: z.number().int().optional(),
        descender: z.number().int().optional(),
        defaultLsb: z.number().int().min(0).max(2000).optional(),
        defaultRsb: z.number().int().min(0).max(2000).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        const project = await getFontProjectById(id);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateFontProject(id, data);
        return { success: true };
      }),

    setDefaultSideBearings: protectedProcedure
      .input(z.object({
        id: z.number(),
        defaultLsb: z.number().int().min(0).max(2000),
        defaultRsb: z.number().int().min(0).max(2000),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.id);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateProjectDefaultSideBearings(input.id, input.defaultLsb, input.defaultRsb);
        return { success: true };
      }),

    applyDefaultSideBearingsToAll: protectedProcedure
      .input(z.object({
        id: z.number(),
        defaultLsb: z.number().int().min(0).max(2000),
        defaultRsb: z.number().int().min(0).max(2000),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.id);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateProjectDefaultSideBearings(input.id, input.defaultLsb, input.defaultRsb);
        // Reset all per-glyph overrides to null (inherit project default)
        await bulkUpdateGlyphSideBearings(input.id, null, null);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.id);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await deleteFontProject(input.id);
        return { success: true };
      }),
  }),

  glyph: router({
    list: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        return getGlyphsByProject(input.projectId);
      }),

    upload: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        unicode: z.number().int(),
        char: z.string(),
        svgBase64: z.string(),
        width: z.number().int().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

        const svgBuffer = Buffer.from(input.svgBase64, "base64");
        const key = `glyphs/${ctx.user.id}/${input.projectId}/uni${input.unicode.toString(16).toUpperCase().padStart(4, "0")}-${nanoid(8)}.svg`;
        const { url } = await storagePut(key, svgBuffer, "image/svg+xml");

        const id = await upsertGlyph({
          projectId: input.projectId,
          unicode: input.unicode,
          char: input.char,
          svgUrl: url,
          svgKey: key,
          width: input.width ?? 600,
        });

        return { id, svgUrl: url };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number(), projectId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await deleteGlyph(input.id);
        return { success: true };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const glyph = await getGlyphById(input.id);
        if (!glyph) throw new TRPCError({ code: "NOT_FOUND" });
        const project = await getFontProjectById(glyph.projectId);
        if (!project || project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        return glyph;
      }),

    updateWidth: protectedProcedure
      .input(z.object({ id: z.number(), projectId: z.number(), width: z.number().int().min(0).max(4096) }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateGlyphWidth(input.id, input.width);
        return { success: true };
      }),

    updatePathData: protectedProcedure
      .input(z.object({ id: z.number(), projectId: z.number(), pathData: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateGlyphPathData(input.id, input.pathData);
        return { success: true };
      }),

    updateSideBearings: protectedProcedure
      .input(z.object({
        id: z.number(),
        projectId: z.number(),
        lsb: z.number().int().min(0).max(2000).nullable(),
        rsb: z.number().int().min(0).max(2000).nullable(),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateGlyphSideBearings(input.id, input.lsb, input.rsb);
        return { success: true };
      }),

    autoSideBearings: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

        const glyphList = await getGlyphsByProject(input.projectId);
        if (glyphList.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "No glyphs" });

        const glyphSummary = glyphList.map(g => ({ id: g.id, char: g.char, unicode: g.unicode, width: g.width }));

        let suggestions: Array<{ id: number; lsb: number; rsb: number }> = [];
        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: "You are a professional type designer. Output only valid JSON." },
              { role: "user", content: `Suggest left side bearing (lsb) and right side bearing (rsb) in font units (UPM=${project.upm}) for each glyph. Rules: 0-300 range, round to multiples of 5, Japanese/CJK use 0, be consistent within categories. Glyphs: ${JSON.stringify(glyphSummary)}` },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "side_bearings",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    bearings: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "integer" },
                          lsb: { type: "integer" },
                          rsb: { type: "integer" },
                        },
                        required: ["id", "lsb", "rsb"],
                        additionalProperties: false,
                      },
                    },
                  },
                  required: ["bearings"],
                  additionalProperties: false,
                },
              },
            },
          });
          const rawContent = response.choices?.[0]?.message?.content ?? "{}";
          const content = typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent);
          const parsed = JSON.parse(content);
          suggestions = parsed.bearings ?? [];
        } catch (e) {
          console.error("[autoSideBearings] LLM error:", e);
          // Fallback: 5% of width, min 20
          suggestions = glyphList.map(g => ({
            id: g.id,
            lsb: Math.max(20, Math.round(g.width * 0.05)),
            rsb: Math.max(20, Math.round(g.width * 0.05)),
          }));
        }

        for (const s of suggestions) {
          if (!glyphList.find(g => g.id === s.id)) continue;
          const lsb = Math.max(0, Math.min(2000, Math.round(s.lsb)));
          const rsb = Math.max(0, Math.min(2000, Math.round(s.rsb)));
          await updateGlyphSideBearings(s.id, lsb, rsb);
        }

        return { applied: suggestions.length };
      }),
  }),

  font: router({
    generate: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        format: z.enum(["ttf", "otf"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

        const glyphList = await getGlyphsByProject(input.projectId);
        if (glyphList.length === 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "No glyphs uploaded yet" });
        }

        const config = {
          name: project.name,
          author: project.author ?? "Unknown",
          upm: project.upm,
          ascender: project.ascender,
          descender: project.descender,
          defaultLsb: project.defaultLsb,
          defaultRsb: project.defaultRsb,
          glyphs: glyphList.map(g => ({
            unicode: g.unicode,
            svgUrl: g.svgUrl,
            width: g.width,
            pathData: g.pathData ?? null,
            lsb: g.lsb ?? null,
            rsb: g.rsb ?? null,
          })),
        };

        const tmpDir = os.tmpdir();
        const configPath = path.join(tmpDir, `font-config-${nanoid()}.json`);
        const outputPath = path.join(tmpDir, `${project.name.replace(/\s+/g, "_")}-${nanoid()}.${input.format}`);

        fs.writeFileSync(configPath, JSON.stringify(config));

        const scriptPath = path.join(process.cwd(), "server", "generate_font.py");

        try {
          const { stdout, stderr } = await execAsync(
            `/usr/bin/python3.11 "${scriptPath}" "${configPath}" "${outputPath}" "${input.format}"`,
            {
              timeout: 120000,
              env: {
                ...process.env,
                PYTHONHOME: undefined,
                PYTHONPATH: undefined,
              } as NodeJS.ProcessEnv,
            }
          );
          if (stderr) console.warn("[FontGen] stderr:", stderr);
          console.log("[FontGen] stdout:", stdout);
        } catch (err: any) {
          console.error("[FontGen] error:", err);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: `Font generation failed: ${err.message}` });
        } finally {
          fs.unlinkSync(configPath);
        }

        const fontBuffer = fs.readFileSync(outputPath);
        fs.unlinkSync(outputPath);

        const mimeType = input.format === "ttf" ? "font/ttf" : "font/otf";
        const fileKey = `fonts/${ctx.user.id}/${input.projectId}/${project.name.replace(/\s+/g, "_")}-${nanoid(8)}.${input.format}`;
        const { url } = await storagePut(fileKey, fontBuffer, mimeType);

        await saveFontFile({
          projectId: input.projectId,
          format: input.format,
          fileUrl: url,
          fileKey,
        });

        return { url, format: input.format };
      }),

    listFiles: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await getFontProjectById(input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND" });
        if (project.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        return getFontFilesByProject(input.projectId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
