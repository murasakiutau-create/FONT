import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { createPool } from "mysql2";
import { InsertUser, users, fontProjects, glyphs, fontFiles, InsertFontProject, InsertGlyph, InsertFontFile } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      // Use a connection pool with reconnect support to survive server restarts
      const pool = createPool({
        uri: process.env.DATABASE_URL,
        connectionLimit: 5,
        waitForConnections: true,
        enableKeepAlive: true,
        keepAliveInitialDelay: 10000,
      });
      _db = drizzle(pool);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get user: database not available"); return undefined; }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Font Projects
export async function createFontProject(data: InsertFontProject) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(fontProjects).values(data);
  return result.insertId as number;
}

export async function getFontProjectsByUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.select().from(fontProjects).where(eq(fontProjects.userId, userId));
}

export async function getFontProjectById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const rows = await db.select().from(fontProjects).where(eq(fontProjects.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function updateFontProject(id: number, data: Partial<InsertFontProject>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(fontProjects).set(data).where(eq(fontProjects.id, id));
}

export async function deleteFontProject(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(fontProjects).where(eq(fontProjects.id, id));
}

// Glyphs
export async function upsertGlyph(data: InsertGlyph) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Delete existing glyph for same project+unicode, then insert
  await db.delete(glyphs).where(and(eq(glyphs.projectId, data.projectId), eq(glyphs.unicode, data.unicode)));
  const [result] = await db.insert(glyphs).values(data);
  return result.insertId as number;
}

export async function getGlyphsByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.select().from(glyphs).where(eq(glyphs.projectId, projectId));
}

export async function deleteGlyph(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(glyphs).where(eq(glyphs.id, id));
}

export async function updateGlyphWidth(id: number, width: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(glyphs).set({ width }).where(eq(glyphs.id, id));
}

export async function updateGlyphPathData(id: number, pathData: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Empty string means "reset to original SVG" - store as null
  const value = pathData.trim() === "" ? null : pathData;
  await db.update(glyphs).set({ pathData: value }).where(eq(glyphs.id, id));
}

export async function getGlyphById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const rows = await db.select().from(glyphs).where(eq(glyphs.id, id)).limit(1);
  return rows[0] ?? null;
}

// Font Files
export async function saveFontFile(data: InsertFontFile) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Remove old file of same format for same project
  await db.delete(fontFiles).where(and(eq(fontFiles.projectId, data.projectId), eq(fontFiles.format, data.format)));
  const [result] = await db.insert(fontFiles).values(data);
  return result.insertId as number;
}

export async function getFontFilesByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.select().from(fontFiles).where(eq(fontFiles.projectId, projectId));
}

// Side Bearings
export async function updateGlyphSideBearings(id: number, lsb: number | null, rsb: number | null) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(glyphs).set({ lsb, rsb }).where(eq(glyphs.id, id));
}

export async function bulkUpdateGlyphSideBearings(projectId: number, lsb: number | null, rsb: number | null) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(glyphs).set({ lsb, rsb }).where(eq(glyphs.projectId, projectId));
}

export async function updateProjectDefaultSideBearings(id: number, defaultLsb: number, defaultRsb: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(fontProjects).set({ defaultLsb, defaultRsb }).where(eq(fontProjects.id, id));
}
