import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock db and storage modules
vi.mock("./db", () => ({
  createFontProject: vi.fn().mockResolvedValue(1),
  getFontProjectsByUser: vi.fn().mockResolvedValue([]),
  getFontProjectById: vi.fn().mockResolvedValue(null),
  updateFontProject: vi.fn().mockResolvedValue(undefined),
  deleteFontProject: vi.fn().mockResolvedValue(undefined),
  upsertGlyph: vi.fn().mockResolvedValue(1),
  getGlyphsByProject: vi.fn().mockResolvedValue([]),
  deleteGlyph: vi.fn().mockResolvedValue(undefined),
  saveFontFile: vi.fn().mockResolvedValue(1),
  getFontFilesByProject: vi.fn().mockResolvedValue([]),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://example.com/test.svg", key: "test/key.svg" }),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 42,
    openId: "test-user-42",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("fontProject", () => {
  it("list returns empty array when no projects", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.fontProject.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result).toHaveLength(0);
  });

  it("create returns an id", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.fontProject.create({ name: "TestFont", upm: 1000, ascender: 800, descender: -200 });
    expect(result).toHaveProperty("id");
    expect(result.id).toBe(1);
  });

  it("get throws NOT_FOUND when project does not exist", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.fontProject.get({ id: 999 })).rejects.toThrow("NOT_FOUND");
  });
});

describe("glyph", () => {
  it("list throws NOT_FOUND when project does not exist", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.glyph.list({ projectId: 999 })).rejects.toThrow("NOT_FOUND");
  });
});

describe("font.listFiles", () => {
  it("throws NOT_FOUND when project does not exist", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.font.listFiles({ projectId: 999 })).rejects.toThrow("NOT_FOUND");
  });
});
